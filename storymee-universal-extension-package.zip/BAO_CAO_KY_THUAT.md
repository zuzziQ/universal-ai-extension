# Báo Cáo Kỹ Thuật: Hệ Thống StoryMee Universal AI Director

Tài liệu này mô tả chi tiết cơ chế hoạt động cốt lõi của **Universal AI Director** (v1.0.4), đặc biệt tập trung vào cách extension kết nối với hệ thống Job trung tâm và cách thức can thiệp ngầm để tạo ảnh/video trên các nền tảng AI.

---

## 1. Cơ Chế Kết Nối Hệ Thống Job Theo Chuẩn Architecture Mới

Để đảm bảo extension luôn nhận được lệnh tạo ảnh/video ngay lập tức (real-time) mà không bị giới hạn bởi Service Worker của Chrome (Manifest V3), hệ thống áp dụng kiến trúc sau:

- **Offscreen Document (`offscreen.ts`):** 
  Extension mở một trang ẩn (offscreen) để khởi tạo và duy trì kết nối liên tục qua giao thức WebSocket tới Gateway Trung Tâm của hệ thống (dev-hub/hub).
  
- **Định Tuyến Gateway (Domain-Driven Routing):** 
  Theo chuẩn kiến trúc mới, toàn bộ giao tiếp đi thẳng qua Gateway (cổng 5100). WebSocket sẽ kết nối tới đường dẫn:
  `wss://dev-hub.storymee.com/v1/media/gflow-extension/ws`
  Quá trình này giúp gửi "heartbeat" (nhịp tim) đều đặn, đảm bảo kết nối không bao giờ bị ngắt, đồng thời vượt qua các giới hạn đóng băng tiến trình của trình duyệt Chrome.

- **Tiếp Nhận & Điều Phối (`background.ts` - `handleGenerateJob`):** 
  Khi WebSocket nhận được một Job mới (bao gồm `task_id`, `prompt`, `media_type`, `project_id`), lệnh sẽ được đẩy về Service Worker (`background.ts`). Tại đây, hệ thống sẽ:
  1. Phân loại Job (Image/Video) và tiền xử lý (làm sạch prompt nếu đó là cảnh quan/đạo cụ).
  2. Ghi nhận trạng thái `processing` vào lịch sử bộ nhớ cục bộ (IndexedDB).
  3. Phân bổ công việc (Dispatch) đến đúng Driver (Dreamina, Picsart, TopView, hoặc GFlow) dựa trên cấu hình hiện tại.

---

## 2. Cơ Chế Bắt & Điều Khiển API Tạo Ảnh/Video Ngầm (Dreamina, Picsart)

Điểm nổi bật nhất của extension là khả năng chạy ngầm (Headless) và can thiệp sâu vào luồng API gốc của các trang web AI (như Dreamina) thông qua kỹ thuật **API Interception & Monkey Patching**.

### A. Tiêm Mã Vào Môi Trường Gốc (MAIN World Injection)
- File `content_dreamina_main.ts` được bơm trực tiếp vào môi trường thực thi gốc của trang web (MAIN World) thay vì môi trường cách ly (ISOLATED World).
- Tại đây, hệ thống tiến hành ghi đè (override) hàm `window.fetch` mặc định của trình duyệt để "nghe lén" toàn bộ các lượt gọi API đi và về giữa trình duyệt và máy chủ.

### B. Bắt Lệnh Generate & Phân Tích Dữ Liệu
- Khi có một lệnh tạo ảnh/video được gửi đi, extension sẽ bắt được gói tin `/api/generate`. Trích xuất (parse) các thông số quan trọng như: `submit_id`, `prompt`, `model`, `aspect_ratio`.

### C. Theo Dõi Kết Quả & Đồng Bộ (Syncing)
- Các dữ liệu trích xuất được sẽ gửi qua `window.postMessage` về lại extension. Lập tức, hệ thống đóng gói thành "Direct Job" và gọi HTTP API (`syncDirectJobsToHub`) báo cáo về Gateway.
- Khi tiến trình hoàn tất, extension bắt lấy URL ảnh/video (mp4, jpg) từ Response của API Polling và đồng bộ thẳng về Hub.

---

## 3. Phân Tích Chuyên Sâu Luồng Tự Động Hóa Google Flow (Google Labs)

Đối với hệ thống **Google Flow (GFlow)**, do tính chất bảo mật cực cao của Google, extension sử dụng một kiến trúc tinh vi (Driver) được thiết kế riêng biệt trong `GoogleLabsDriver.ts` và `googleLabsApi.ts`:

### A. Quản Lý Khóa Tuần Tự (Mutex Lock)
Để tránh tình trạng gửi dồn dập khiến Google đánh dấu là spam hoặc lỗi tải trang, mọi Job gửi đến GFlow đều đi qua một khoá Mutex (`gflowLockPromise`). Các Job phải xếp hàng và chạy nối tiếp nhau một cách an toàn.

### B. Cơ Chế Xác Thực & Vượt reCAPTCHA v3 Tự Động
- **Đánh cắp Cookie & Token an toàn:** Extension lấy trực tiếp các mã `oauthToken`, `xBrowserValidation`, và `xClientData` từ Chrome Storage. Nếu thiếu, extension tự động tìm kiếm một tab ẩn đang mở trang `labs.google` để trích xuất token.
- **Tự Động Giải Mã reCAPTCHA:** Trước khi gọi API tạo ảnh/video, hệ thống tự động tiêm một script ẩn vào trang web để kích hoạt `grecaptcha.execute()` (với Action là `IMAGE_GENERATION` hoặc `VIDEO_GENERATION`). Lấy được Token reCAPTCHA mới nhất, đảm bảo API của Google luôn hợp lệ.

### C. Kỹ Thuật Lách Bộ Lọc Từ Khóa (Prompt Sanitization)
Vì bộ lọc nội dung nhạy cảm của Google (Safety Filters) rất khắt khe, extension tự động chạy qua bộ lọc tiền xử lý `sanitizeUnsafePrompt`:
- Thay thế các từ khóa dễ bị "hiểu nhầm": Ví dụ `knife` -> `cooking tool`, `blood` -> `dramatic action`.
- Tự động cắt gọn mô tả (Truncation) nếu Prompt dài hơn 500 ký tự (giữ 300 ký tự đầu quan trọng và 180 ký tự cuối chứa style layout) để tránh API báo lỗi payload quá tải.

### D. Thực Thi Native API (Tab Execute Fetch)
Google API (các endpoint `trpc/media.generateImages` hay `trpc/media.generateVideos`) chặn các Request gọi từ môi trường ngoài nếu thiếu Fingerprint của trình duyệt. 
=> **Giải pháp:** Extension dùng hàm `chrome.scripting.executeScript` để ép (force) một tab đang mở trang `labs.google` thực thi ngầm hàm `window.fetch` gửi API đi với tham số `credentials: 'include'`. Bằng cách này, Google nhận diện đây là một hành vi hoàn toàn bình thường từ người dùng trên tab.

### E. Quản Lý Project Linh Hoạt
Nếu Job yêu cầu một bối cảnh (Project ID) cụ thể, Extension sẽ dùng API điều khiển tab đó nhảy thẳng vào đường dẫn project tương ứng (`/fx/tools/flow/project/[ID]`) trước khi tiến hành render, giúp kế thừa toàn bộ bối cảnh đồ họa đã thiết lập trong Project gốc của Google Flow.
