import { ResilientWebSocket } from './utils/extension-sdk';

let wsManager: ResilientWebSocket | null = null;
let lastStatusUpdate = 0;
let activeGflowJobs = 0;

// =======================================================================
// STORAGE PROXY - Offscreen documents ONLY have chrome.runtime APIs
// chrome.storage, chrome.cookies etc. are NOT available here.
// Must use message passing to Service Worker (background.ts) instead.
// =======================================================================

function storageGet(keys: string[]): Promise<any> {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: "PROXY_STORAGE_GET", keys }, (response) => {
        if (chrome.runtime.lastError) { resolve({}); return; }
        resolve(response?.data || {});
      });
    } catch { resolve({}); }
  });
}

function storageSet(data: Record<string, any>): Promise<void> {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: "PROXY_STORAGE_SET", data }, () => resolve());
    } catch { resolve(); }
  });
}

function cookiesGetAll(domain: string): Promise<any[]> {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: "PROXY_COOKIES_GET", domain }, (response) => {
        if (chrome.runtime.lastError) { resolve([]); return; }
        resolve(response?.cookies || []);
      });
    } catch { resolve([]); }
  });
}

function broadcastStatus(status: string) {
  storageSet({ workerState: status }).catch(() => {});
  chrome.runtime.sendMessage({ type: "WS_STATUS", status }).catch(() => {});
}

async function checkWebSocket() {
  const data = await storageGet([
    "gflowUrl", "googleEmail", "clientUuid", "workerName",
    "hub_api_key", "dreamina_api_key", "picsart_api_key",
    "topview_api_key", "gflow_api_key", "disable_ws",
    "selected_provider", "oauthToken"
  ]);

  if (data.disable_ws === true) {
    console.log("[Offscreen] WebSocket connection is disabled via disable_ws storage configuration.");
    if (wsManager) {
      try { wsManager.close(); } catch {}
      wsManager = null;
    }
    return;
  }

  const gflowUrl = data.gflowUrl || "https://hub.storymee.com";
  // googleEmail chỉ dùng cho Google Flow automation, không dùng làm WS identity
  // const googleEmail = data.googleEmail;
  let clientUuid = data.clientUuid;
  
  const selectedProvider = data.selected_provider || 'DREAMINA';
  let apiKey = "";
  if (selectedProvider === 'GFLOW') {
    apiKey = data.gflow_api_key || data.hub_api_key || "";
  } else if (selectedProvider === 'PICSART') {
    apiKey = data.picsart_api_key || data.hub_api_key || "";
  } else if (selectedProvider === 'TOPVIEW') {
    apiKey = data.topview_api_key || data.hub_api_key || "";
  } else {
    apiKey = data.dreamina_api_key || data.hub_api_key || "";
  }

  if (!clientUuid) {
    clientUuid = Math.random().toString(36).substring(2) + Date.now().toString(36);
    await storageSet({ clientUuid });
  }

  // Already connected - just heartbeat
  if (wsManager && wsManager.ws && wsManager.ws.readyState === WebSocket.OPEN) {
    const now = Date.now();
    if (now - lastStatusUpdate > 30000) {
      wsManager.send({ action: "STATUS_UPDATE", status: "ONLINE" });
      lastStatusUpdate = now;
    }
    return;
  }

  if (wsManager) wsManager.close();

  const cookies = await cookiesGetAll(".google.com");
  const sessionCookie = cookies.find((c: any) => c.name === "__Secure-1PSID");

  // email: tên worker instance (tùy chỉnh), KHÔNG phải Google email
  // Google email chỉ dùng cho Google Flow automation bên trong
  const workerInstanceName = data.workerName
    || (sessionCookie ? `ext_${sessionCookie.value.slice(-6)}@flow.local` : "universal-director");
  // Email = tên worker để hiển thị trên monitoring Hub
  const email = workerInstanceName;

  let wsUrl = "";
  try {
    let url = (gflowUrl || "https://hub.storymee.com").trim();
    if (!url.includes("://")) url = "http://" + url;
    const urlObj = new URL(url);
    const proto = (urlObj.protocol === "https:" || urlObj.protocol === "wss:") ? "wss:" : "ws:";
    // api_key gửi qua query param để Hub resolve UUID cho dispatch routing
    const keyParam = apiKey ? `&api_key=${encodeURIComponent(apiKey)}` : "";
    wsUrl = `${proto}//${urlObj.host}/v1/media/gflow-extension/ws?email=${encodeURIComponent(email)}${keyParam}`;
  } catch {
    const keyParam = apiKey ? `&api_key=${encodeURIComponent(apiKey)}` : "";
    wsUrl = `wss://hub.storymee.com/v1/media/gflow-extension/ws?email=${encodeURIComponent(email)}${keyParam}`;
  }

  console.log(`[Offscreen] Connecting to: ${wsUrl}`);

  wsManager = new ResilientWebSocket(wsUrl, {
    reconnectInterval: 5000,
    maxReconnectAttempts: 50,
    pingInterval: 25000,
    workerId: email,
    workerName: workerInstanceName
  });

  // Override broadcastStatus: chrome.storage NOT available in offscreen
  // Must use message proxy
  wsManager.broadcastStatus = (status: string) => {
    broadcastStatus(status);
    wsManager?.trigger("stateChange", status);
  };

  wsManager.on("open", () => {
    console.log("[Offscreen] WebSocket Connected!");
    if (wsManager) {
      const googleEmail = data.googleEmail || "";
      const oauthToken = data.oauthToken || "";
      wsManager.send({ action: "REGISTER", email, client_uuid: clientUuid, google_email: googleEmail, oauth_token: oauthToken });
      wsManager.send({ action: "STATUS_UPDATE", status: "ONLINE" });
      lastStatusUpdate = Date.now();
    }
  });

  wsManager.on("message", (msg: any) => {
    if (msg.action === "GENERATE") {
      const provider = (msg.provider || "").toUpperCase();
      const isGflow = ["GFLOW", "GOOGLE_FLOW", "GOOGLE-ULTRA", "GOOGLE_ULTRA", "GOOGLE-LABS-ULTRA", "GOOGLE_LABS_ULTRA"].includes(provider);

      if (isGflow) {
        if (activeGflowJobs >= 1) {
          console.warn(`[Offscreen] GFlow concurrency limit reached. Rejecting job: ${msg.task_id || msg.jobId}`);
          if (wsManager) {
            wsManager.send({
              action: "JOB_REJECT",
              taskId: msg.task_id || msg.jobId,
              task_id: msg.task_id || msg.jobId,
              reason: "gflow_concurrency_limit_reached"
            });
          }
          return;
        }

        activeGflowJobs++;
        if (wsManager) {
          wsManager.send({
            action: "JOB_ACK",
            taskId: msg.task_id || msg.jobId,
            task_id: msg.task_id || msg.jobId,
            provider: msg.provider || "gflow"
          });
        }

        chrome.runtime.sendMessage({ type: "GENERATE_JOB", payload: msg }, () => {
          activeGflowJobs = Math.max(0, activeGflowJobs - 1);
          console.log(`[Offscreen] GFlow job ${msg.task_id || msg.jobId} finished. Active GFlow count: ${activeGflowJobs}`);
        });
      } else {
        if (wsManager) {
          wsManager.send({
            action: "JOB_ACK",
            taskId: msg.task_id || msg.jobId,
            task_id: msg.task_id || msg.jobId,
            provider: msg.provider
          });
        }
        chrome.runtime.sendMessage({ type: "GENERATE_JOB", payload: msg }).catch(() => {});
      }
    } else if (msg.action === "CHECK_SESSION") {
      chrome.storage.local.get(["oauthToken", "googleEmail"], (result) => {
        if (wsManager) {
          wsManager.send({
            action: "SESSION_STATUS_PONG",
            provider: "gflow",
            email: result.googleEmail,
            sessionReady: !!result.oauthToken,
          });
        }
      });
    }
  });

  wsManager.connect();
}

// ===== Message listener =====
chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (request.type === "SUBMIT_RESULT_WS") {
    const { taskId, provider, result } = request;
    if (wsManager?.ws?.readyState === WebSocket.OPEN) {
      try {
        let flowResponse: any = { result: { urls: result.outputUrls || [] } };
        if (result.rawResponse) {
          if (typeof result.rawResponse === 'object') {
            flowResponse = result.rawResponse.candidates
              ? result.rawResponse
              : { ...result.rawResponse, result: { urls: result.outputUrls || [] } };
          } else if (typeof result.rawResponse === 'string') {
            flowResponse = { candidates: [{ content: { parts: [{ text: result.rawResponse }] } }] };
          }
        }
        if (result.actualMeta) {
          flowResponse.actualMeta = result.actualMeta;
        }
        wsManager.send({ action: "RESULT", task_id: taskId, provider, flow_response: flowResponse,
          error: result.success ? "" : (result.error || "Unknown error"), email: result.email || "" });
        sendResponse({ success: true });
      } catch (err: any) {
        sendResponse({ success: false, error: err.message });
      }
    } else {
      sendResponse({ success: false, error: "WS_NOT_OPEN" });
    }
    return true;
  }

  if (request.type === "PING_OFFSCREEN") {
    sendResponse({ status: "ALIVE" });
    return true;
  }

  if (request.type === "FORCE_RECONNECT_WS") {
    if (wsManager) wsManager.close();
    checkWebSocket()
      .then(() => sendResponse({ success: true }))
      .catch((err: any) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // Background forwards storage change events here
  if (request.type === "STORAGE_CHANGED_NOTIFY") {
    const ch = request.changes;
    if (ch.hub_api_key || ch.dreamina_api_key || ch.picsart_api_key
      || ch.topview_api_key || ch.gflow_api_key || ch.gflowUrl || ch.selected_provider) {
      if (wsManager) wsManager.close();
      checkWebSocket().catch(() => {});
    }
    return false;
  }

  return false;
});

// Boot
console.log("[Offscreen] Booting with message-based storage proxy...");
setInterval(checkWebSocket, 15000);
checkWebSocket();
