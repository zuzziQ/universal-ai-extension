import { CoreApiClient } from '@storymee/api-client';


export async function getHubApiClient(enforceApiPrefix: boolean = false): Promise<CoreApiClient> {
  return new Promise((resolve) => {
    chrome.storage.local.get(["gflowUrl", "hub_api_key"], (data: any) => {
      let apiBase = (data.gflowUrl as string) || "https://hub.storymee.com";
      
      // If user inputs a ws:// url, we fix it to http
      if (apiBase.includes("ws://")) {
        apiBase = apiBase.replace("ws://", "http://");
      } else if (apiBase.includes("wss://")) {
        apiBase = apiBase.replace("wss://", "https://");
      }

      const apiKey = (data.hub_api_key as string) || "";

      const client = new CoreApiClient({
        baseURL: apiBase,
        enforceApiPrefix: enforceApiPrefix,
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "x-api-key": apiKey,
          "Content-Type": "application/json"
        } as any
      });
      resolve(client);
    });
  });
}
