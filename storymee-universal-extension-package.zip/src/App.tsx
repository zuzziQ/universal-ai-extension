import { useState, useEffect } from 'react';
import { getHubApiClient } from './core/api';
import { 
  Activity, 
  Terminal, 
  RefreshCw, 
  ExternalLink, 
  Image as ImageIcon, 
  User, 
  CheckCircle,
  Copy, 
  Globe, 
  Lock, 
  Sparkles, 
  Cpu, 
  Settings, 
  Layers,
  PlusCircle,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Search,
  Eye,
  EyeOff,
  X
} from 'lucide-react';

interface SavedJob {
  id: string;
  mediaType: string;
  prompt: string;
  provider: string;
  status: 'pending' | 'processing' | 'done' | 'failed';
  timestamp: number;
  resultUrl?: string;
  error?: string;
  projectId?: string;
  projectName?: string;
  projectLink?: string;
  executedBy?: string;
  source?: string;
  pool?: string;
  batchName?: string;
  modelDisp?: string;
  ratioDisp?: string;
  durationDisp?: string;
  inputParams?: any;
}

function formatRatio(ratio: any): string {
  if (!ratio) return '—';
  const r = String(ratio).toUpperCase().trim();
  if (r.includes('PORTRAIT') || r === '9:16') return '9:16';
  if (r.includes('LANDSCAPE') || r === '16:9') return '16:9';
  if (r.includes('SQUARE') || r === '1:1') return '1:1';
  return r;
}

// Định nghĩa component Job// Định nghĩa component JobCard
function JobCard({ job, copyToClipboard, onMediaError, onViewDetails, onSwitchAccount }: { job: SavedJob; copyToClipboard: (text: string) => void; onMediaError?: (url: string) => void; onViewDetails: (job: SavedJob) => void; onSwitchAccount?: (provider: string, email: string) => void }) {
  const [mediaError, setMediaError] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const isVideo = job.mediaType === 'video';

  const handleMediaError = () => {
    setMediaError(true);
    if (onMediaError && job.resultUrl) {
      onMediaError(job.resultUrl);
    }
  };

  // Trạng thái đường viền bên trái (status border)
  const borderStatusClass = 
    job.status === 'done' ? 'border-l-[3px] border-l-emerald-500' :
    job.status === 'failed' ? 'border-l-[3px] border-l-rose-500' :
    job.status === 'processing' ? 'border-l-[3px] border-l-amber-500 animate-pulse' :
    'border-l-[3px] border-l-slate-700';

  // Cập nhật phân loại nguồn giống Hub Frontend
  const inputParams = job.inputParams || {};
  const frontendApp = (inputParams.frontendApp || inputParams.frontend_app || '').toLowerCase();
  const projectName = (inputParams.projectName || inputParams.project_name || job.batchName || '').toLowerCase();
  
  let frontendName = 'Hệ Thống Mẹ';
  if (frontendApp.includes('flow-architect') || projectName.includes('flow-architect')) frontendName = 'Flow Architect';
  else if (frontendApp.includes('world-asset') || projectName.includes('world-asset')) frontendName = 'World Asset';
  else if (frontendApp.includes('direct') || frontendApp.includes('web') || projectName.includes('web') || projectName.includes('capcut')) frontendName = 'Direct Web';

  const clientApiKeyStr = inputParams.clientApiKey || '';
  let poolName = 'Internal';
  if ((job.pool || inputParams.pool || '').toLowerCase() === 'partner' || clientApiKeyStr.toLowerCase().includes('partner')) {
      poolName = 'Partner';
  }

  let category = 'LLM';
  const type = (inputParams.jobType || job.mediaType || '').toLowerCase();
  if (type === 'video' || type.includes('video')) category = 'Video';
  else if (type === 'image' || type.includes('image')) category = 'Image';

  // Badges provider colors
  const providerUpper = (job.provider || 'Hub').toUpperCase();
  let providerBadgeClass = 'bg-slate-950 border border-slate-855 text-indigo-400';
  if (providerUpper === 'DREAMINA') {
    providerBadgeClass = 'bg-purple-955/40 text-purple-400 border border-purple-500/20';
  } else if (providerUpper === 'GFLOW' || providerUpper === 'GOOGLE_FLOW') {
    providerBadgeClass = 'bg-emerald-955/40 text-emerald-400 border border-emerald-500/20';
  } else if (providerUpper === 'PICSART') {
    providerBadgeClass = 'bg-blue-955/40 text-blue-400 border border-blue-500/20';
  } else if (providerUpper === 'TOPVIEW') {
    providerBadgeClass = 'bg-amber-955/40 text-amber-400 border border-amber-500/20';
  }

  // Trạng thái hiển thị showcase ở góc phải
  let mediaShowcaseHtml;
  if (job.status === 'done' && job.resultUrl) {
    if (isVideo) {
      mediaShowcaseHtml = mediaError ? (
        <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 text-slate-500" title="Lỗi tải video">
          <AlertCircle className="w-4 h-4 text-amber-500" />
        </div>
      ) : (
        <video 
          src={job.resultUrl} 
          className="w-full h-full object-cover cursor-pointer hover:scale-110 transition-transform duration-200" 
          onError={handleMediaError}
          muted
          playsInline
          autoPlay
          loop
          controls={false}
          onClick={() => onViewDetails(job)}
          {...{ referrerPolicy: "no-referrer" }}
        />
      );
    } else if (job.mediaType === 'image' && !job.resultUrl.startsWith('{') && !job.resultUrl.startsWith('[')) {
      mediaShowcaseHtml = mediaError ? (
        <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 text-slate-500" title="Lỗi tải ảnh">
          <AlertCircle className="w-4 h-4 text-amber-500" />
        </div>
      ) : (
        <img 
          src={job.resultUrl} 
          alt="Preview" 
          className="w-full h-full object-cover cursor-pointer hover:scale-110 transition-transform duration-200" 
          onError={handleMediaError}
          onClick={() => onViewDetails(job)}
          referrerPolicy="no-referrer"
        />
      );
    } else {
      mediaShowcaseHtml = (
        <div className="w-full h-full flex items-center justify-center bg-slate-955 text-slate-400 text-[8px] font-mono p-1 break-all overflow-hidden text-ellipsis" onClick={() => onViewDetails(job)}>
          TXT
        </div>
      );
    }
  } else if (job.status === 'processing') {
    mediaShowcaseHtml = <div className="text-amber-400 text-xs animate-pulse">⏳</div>;
  } else if (job.status === 'failed') {
    mediaShowcaseHtml = <div className="text-rose-400 text-xs">❌</div>;
  } else {
    mediaShowcaseHtml = <div className="text-slate-500 text-xs">🕐</div>;
  }

  return (
    <div className={`bg-slate-900/40 border border-slate-850 hover:border-slate-800 rounded-xl p-3 flex flex-col gap-2 transition-all duration-200 shadow-md ${borderStatusClass}`}>
      {/* Row 1: Badges & Status */}
      <div className="flex justify-between items-center gap-2 w-full">
        <div className="flex flex-wrap items-center gap-1">
          {/* Frontend */}
          <span className="bg-slate-800/80 text-slate-300 border border-slate-700/50 text-[8.5px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1">
            💻 {frontendName}
          </span>
          {/* Pool Badge */}
          <span className={`text-[8.5px] px-1.5 py-0.5 rounded font-extrabold uppercase ${
            poolName === 'Partner' 
              ? 'bg-amber-955/45 text-amber-400 border border-amber-500/20' 
              : 'bg-slate-800/80 text-slate-400 border border-slate-700/50'
          }`}>
            {poolName === 'Partner' ? '🤝 Partner' : '🏠 Internal'}
          </span>
          {/* Category Badge */}
          <span className={`text-[8.5px] px-1.5 py-0.5 rounded font-extrabold uppercase ${
            category === 'Video' 
              ? 'bg-purple-955/45 text-purple-400 border border-purple-500/20' 
              : category === 'Image'
                ? 'bg-emerald-955/45 text-emerald-400 border border-emerald-500/20'
                : 'bg-blue-955/45 text-blue-400 border border-blue-500/20'
          }`}>
            {category === 'Video' ? '🎥 Video' : category === 'Image' ? '🖼️ Image' : category}
          </span>
          {/* Provider */}
          <span className={`text-[8.5px] px-1.5 py-0.5 rounded font-extrabold uppercase ${providerBadgeClass}`}>
            {providerUpper}
          </span>
        </div>

        {/* Status Badge */}
        <span className={`text-[8.5px] px-1.5 py-0.5 rounded font-extrabold uppercase ${
          job.status === 'done' ? 'bg-emerald-955/80 text-emerald-400 border border-emerald-900/30' :
          job.status === 'failed' ? 'bg-rose-955/80 text-rose-455 border border-rose-900/30' :
          'bg-amber-955/80 text-amber-400 border border-amber-900/30 animate-pulse'
        }`}>
          {job.status}
        </span>
      </div>

      {/* Row 2: Prompt + Params & Preview (Side by Side) */}
      <div className="flex gap-3 items-start w-full">
        {/* Cột trái: Prompt & Params */}
        <div className="flex-1 min-w-0 flex flex-col gap-2">
          {/* Prompt */}
          <div className="text-xs font-semibold text-slate-202 italic leading-relaxed">
            <span 
              style={isExpanded ? {} : {
                display: '-webkit-box',
                WebkitLineClamp: 2,
                WebkitBoxOrient: 'vertical',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
              }}
              className="mb-1 block"
            >
              "{job.prompt}"
            </span>
            <div className="flex gap-2">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setIsExpanded(!isExpanded);
                }}
                className="text-indigo-400 hover:text-indigo-300 font-bold text-[9px] hover:underline cursor-pointer inline-block"
              >
                {isExpanded ? '[Thu gọn]' : '[Xem thêm]'}
              </button>
              <button 
                onClick={() => onViewDetails(job)}
                className="text-slate-400 hover:text-slate-350 font-bold text-[9px] hover:underline cursor-pointer inline-block"
              >
                [Chi tiết]
              </button>
            </div>
          </div>

          {/* Reference Images Row */}
          {(() => {
            const refImg = job.inputParams?.reference_image || job.inputParams?.referenceImage;
            const refUrls = job.inputParams?.reference_image_urls || job.inputParams?.referenceImageUrls;
            const refImages: string[] = [];
            if (refImg && typeof refImg === 'string' && refImg.startsWith('http')) {
              refImages.push(refImg);
            }
            if (Array.isArray(refUrls)) {
              refUrls.forEach((u: any) => {
                if (typeof u === 'string' && u.startsWith('http') && !refImages.includes(u)) {
                  refImages.push(u);
                }
              });
            }
            if (refImages.length === 0) return null;
            return (
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-[8px] text-slate-500 font-bold uppercase">Refs:</span>
                <div className="flex gap-1">
                  {refImages.map((imgUrl, idx) => (
                    <div key={idx} className="w-6 h-6 rounded overflow-hidden border border-white/10 bg-slate-950 flex-shrink-0 cursor-zoom-in group relative">
                      <img 
                        src={imgUrl} 
                        alt={`Ref ${idx}`} 
                        className="w-full h-full object-cover hover:scale-125 transition-transform" 
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open(imgUrl, '_blank');
                        }}
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

          {/* Expanded parameters */}
          {isExpanded && job.inputParams && (
            <div className="mt-1 p-2 bg-slate-955/80 rounded-lg border border-slate-850 font-mono text-[9px] text-slate-400 space-y-1 overflow-x-auto max-w-full">
              <div className="font-bold text-slate-350 mb-0.5 uppercase text-[8px] tracking-wider">Parameters:</div>
              {Object.entries(job.inputParams).map(([key, val]) => {
                if (key === 'prompt' || key === 'reference_image' || key === 'reference_image_urls' || key === 'reference_image_roles') return null;
                if (val === null || val === undefined || val === '') return null;
                return (
                  <div key={key} className="flex justify-between gap-2 border-b border-slate-900/50 pb-0.5">
                    <span className="text-slate-555">{key}:</span>
                    <span className="text-slate-350 truncate max-w-[150px]" title={String(val)}>
                      {typeof val === 'object' ? JSON.stringify(val) : String(val)}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Inline Parameter Tags */}
          <div className="flex flex-wrap gap-1">
            {job.modelDisp && (
              <span className="text-[8.5px] bg-slate-950/60 text-slate-400 border border-slate-850 px-1.5 py-0.5 rounded font-mono" title="Model">
                📐 {job.modelDisp}
              </span>
            )}
            {job.ratioDisp && (
              <span className="text-[8.5px] bg-slate-950/60 text-slate-400 border border-slate-850 px-1.5 py-0.5 rounded font-mono" title="Ratio">
                🖼️ {job.ratioDisp}
              </span>
            )}
            {job.durationDisp && job.durationDisp !== '—' && (
              <span className="text-[8.5px] bg-slate-950/60 text-slate-400 border border-slate-850 px-1.5 py-0.5 rounded font-mono" title="Duration">
                ⏱️ {job.durationDisp}
              </span>
            )}
            {job.batchName && (
              <span className="text-[8.5px] bg-slate-950/30 text-slate-400 border border-slate-900/40 px-1.5 py-0.5 rounded font-mono truncate max-w-[120px]" title={`Batch: ${job.batchName}`}>
                📦 {job.batchName}
              </span>
            )}
          </div>
        </div>

        {/* Cột phải: Media Showcase */}
        <div className="w-[70px] h-[70px] flex-shrink-0 bg-black/40 border border-white/5 rounded-lg overflow-hidden flex items-center justify-center relative">
          {mediaShowcaseHtml}
        </div>
      </div>

      {/* Error message (nếu có) */}
      {job.error && (
        <div className="text-[9px] text-rose-400 italic bg-rose-955/10 p-1.5 rounded border border-rose-500/10 break-words leading-tight w-full">
          <strong>Lỗi:</strong> {job.error}
        </div>
      )}

      {/* Row 3: Meta info (ID & Email badge) */}
      <div className="flex justify-between items-center gap-2 border-t border-slate-800/30 pt-1.5 text-[10px] w-full">
        <span className="text-[8px] font-mono text-slate-500 truncate" title={job.id}>
          ID: {job.id.substring(0, 8)}...
        </span>
        {job.executedBy && (
          <span 
            onClick={() => {
              copyToClipboard(job.executedBy!);
              alert(`Đã copy email: ${job.executedBy}`);
            }}
            className="text-[8px] text-slate-450 truncate max-w-[180px] bg-slate-950 hover:bg-slate-855 border border-slate-850 px-1.5 py-0.5 rounded flex items-center gap-1 cursor-pointer select-all font-semibold" 
            title={`Click để copy email & tìm kiếm: ${job.executedBy}`}
          >
            👤 {job.executedBy}
          </span>
        )}
      </div>

      {/* Row 4: Action buttons stretched to full width */}
      <div className="flex gap-1.5 w-full mt-1 flex-wrap">
        {job.executedBy && (
          <button
            onClick={() => onSwitchAccount && onSwitchAccount(job.provider, job.executedBy!)}
            className="flex-1 min-w-[70px] bg-emerald-950 hover:bg-emerald-900 border border-emerald-500/30 text-emerald-400 font-bold text-[10px] py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all cursor-pointer"
            title="Chuyển nhanh sang tài khoản này"
          >
            <RefreshCw className="w-3 h-3" />
            Switch
          </button>
        )}
        {(providerUpper === 'GFLOW' || providerUpper === 'GOOGLE_FLOW') && (
          <a
            href={job.projectId ? `https://labs.google/fx/tools/flow/project/${job.projectId}` : "https://labs.google/fx/tools/image-fx"}
            target="_blank"
            rel="noreferrer"
            className="flex-1 min-w-[70px] bg-indigo-950 hover:bg-indigo-900 border border-indigo-500/30 text-indigo-400 font-bold text-[10px] py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all cursor-pointer no-underline"
            title="Mở Project Google Flow"
          >
            <ExternalLink className="w-3 h-3" />
            Project
          </a>
        )}
        {job.resultUrl && (
          <>
            <button
              onClick={() => {
                copyToClipboard(job.resultUrl!);
                alert("Đã copy kết quả vào clipboard!");
              }}
              className="flex-1 min-w-[70px] bg-slate-950 hover:bg-slate-850 border border-slate-800 text-[10px] font-bold py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all text-slate-400 hover:text-slate-200 cursor-pointer"
              title="Copy link kết quả"
            >
              <Copy className="w-3 h-3" />
              Copy Link
            </button>
            {(!job.resultUrl.startsWith('{') && !job.resultUrl.startsWith('[') && (job.mediaType === 'video' || job.mediaType === 'image' || job.resultUrl.startsWith('http'))) && (
              <a 
                href={job.resultUrl} 
                target="_blank" 
                rel="noreferrer"
                className="flex-1 min-w-[70px] bg-slate-950 hover:bg-slate-850 border border-slate-800 text-[10px] font-bold py-1.5 rounded-lg flex items-center justify-center gap-1 transition-all text-slate-202 hover:text-slate-100 text-center no-underline cursor-pointer flex justify-center items-center"
                title="Mở link gốc trong tab mới"
              >
                <ExternalLink className="w-3 h-3" />
                Xem gốc
              </a>
            )}
          </>
        )}
      </div>

      {/* Cảnh báo chi tiết nếu media error */}
      {mediaError && job.resultUrl && (
        <div className="text-[8.5px] text-amber-500 bg-amber-955/10 p-1.5 rounded border border-amber-500/10 mt-1 leading-normal w-full">
          ⚠️ <strong>Lỗi SSL/Hết hạn:</strong> Click <strong>Xem gốc</strong> bên trên để bypass cảnh báo chứng chỉ SSL của Chrome.
        </div>
      )}
    </div>
  );
}

export default function App() {
  const isSidepanel = window.location.pathname.includes('sidepanel.html');

  const getRouteBadge = () => {
    if (gflowUrl.includes('localhost') || gflowUrl.includes('127.0.0.1') || gflowUrl.includes('local-hub.storymee.com')) {
      return (
        <span className="text-[8px] font-extrabold uppercase bg-emerald-955/40 border border-emerald-500/30 text-emerald-400 px-2 py-0.5 rounded">
          🏠 Local Route
        </span>
      );
    }
    if (gflowUrl.includes('dev-hub.storymee.com')) {
      return (
        <span className="text-[8px] font-extrabold uppercase bg-blue-955/40 border border-blue-500/30 text-blue-400 px-2 py-0.5 rounded">
          🛠️ Dev Route
        </span>
      );
    }
    if (gflowUrl.includes('173.249.19.167')) {
      return (
        <span className="text-[8px] font-extrabold uppercase bg-amber-955/40 border border-amber-500/30 text-amber-400 px-2 py-0.5 rounded">
          ☁️ VPS Route
        </span>
      );
    }
    return (
      <span className="text-[8px] font-extrabold uppercase bg-purple-955/40 border border-purple-500/30 text-purple-400 px-2 py-0.5 rounded">
        🌐 Prod Route
      </span>
    );
  };

  // Config & WebSocket state
  const [gflowUrl, setGflowUrl] = useState("https://hub.storymee.com");
  const [workerState, setWorkerState] = useState("DISCONNECTED");
  const [googleEmail, setGoogleEmail] = useState("");
  const [googleAvatar, setGoogleAvatar] = useState("");
  const [oauthToken, setOauthToken] = useState("");
  const [xBrowserValidation, setXBrowserValidation] = useState("");
  const [xClientData, setXClientData] = useState("");

  // History & Active Job
  const [failedHosts, setFailedHosts] = useState<string[]>([]);
  const [jobs, setJobs] = useState<SavedJob[]>([]);
  const [selectedJobForModal, setSelectedJobForModal] = useState<SavedJob | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'accounts' | 'history'>('accounts');
  if (false as boolean) {
    setActiveTab(activeTab);
  }
  const [activeExecutor, setActiveExecutor] = useState<any>(null);
  const [rotationLog, setRotationLog] = useState<any[]>([]);

  // Centralized Multi-Account & Provider States
  const [selectedProvider, setSelectedProvider] = useState<'DREAMINA' | 'PICSART' | 'TOPVIEW' | 'GFLOW'>('DREAMINA');

  // 4 Provider accounts states
  const [dreaminaAccounts, setDreaminaAccounts] = useState<any[]>([]);
  const [picsartAccounts, setPicsartAccounts] = useState<any[]>([]);
  const [topviewAccounts, setTopviewAccounts] = useState<any[]>([]);
  const [gflowAccounts, setGflowAccounts] = useState<any[]>([]);

  const [activeEmails, setActiveEmails] = useState<Record<string, string>>({});
  const [hideLowPoints, setHideLowPoints] = useState(false);
  const [hubApiKey, setHubApiKey] = useState("");
  const [showApiKey, setShowApiKey] = useState(false);
  const [workerName, setWorkerName] = useState("");
  const [providerApiKeys, setProviderApiKeys] = useState<Record<string, string>>({
    DREAMINA: "",
    PICSART: "",
    TOPVIEW: "",
    GFLOW: ""
  });
  const [isSyncingAccounts, setIsSyncingAccounts] = useState(false);
  const [verifyingEmail, setVerifyingEmail] = useState<string | null>(null);
  const [isFetchingJobs, setIsFetchingJobs] = useState(false);

  // Accordion state for Session Vault Headers
  const [showVaultHeaders, setShowVaultHeaders] = useState(false);

  // Filter & Search states for jobs
  const [jobStatusFilter, setJobStatusFilter] = useState<'all' | 'processing' | 'done' | 'failed'>('all');
  const [jobSearchQuery, setJobSearchQuery] = useState('');

  const [jobProviderFilter, setJobProviderFilter] = useState<'ALL' | 'DREAMINA' | 'PICSART' | 'TOPVIEW' | 'GFLOW'>('ALL');

  // Legacy Dreamina-specific parameters
  const [dreaminaExecutionMode, setDreaminaExecutionMode] = useState<'extension' | 'headless'>('extension');
  const [currentDreaminaEmail, setCurrentDreaminaEmail] = useState("");
  const [autoSwitchEnabled, setAutoSwitchEnabled] = useState(true);

  // Computed active Dreamina email fallback
  const activeDreaminaEmail = activeEmails.DREAMINA || currentDreaminaEmail;

  // Computed property keeping backward compatibility
  const accountsList = selectedProvider === 'DREAMINA' ? dreaminaAccounts :
                       selectedProvider === 'PICSART' ? picsartAccounts :
                       selectedProvider === 'TOPVIEW' ? topviewAccounts :
                       gflowAccounts;

  // Open Dashboard Full Screen Helper
  const openDashboard = () => {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.tabs) {
      chrome.tabs.create({ url: chrome.runtime.getURL('index.html') });
    } else {
      window.open('/index.html', '_blank');
    }
  };

  const fetchJobsFromHub = async () => {
    if (isFetchingJobs) return;
    setIsFetchingJobs(true);
    try {
      const apiClient = await getHubApiClient();
      
      console.log(`[FE Jobs] Fetching unified jobs via API Client`);
      const resJson = await apiClient.get('/internal/v1/jobs?limit=100');
      
      if (resJson) {
        if (resJson.status === 'success' && Array.isArray(resJson.data)) {
          const mappedJobs = resJson.data.map((job: any): SavedJob => {
            let displayPrompt = "";
            if (job.inputParams && typeof job.inputParams === 'object') {
              displayPrompt = job.inputParams.prompt || job.inputParams.brief || job.inputParams.script || job.prompt || "";
            }
            if (!displayPrompt) {
              displayPrompt = job.prompt || "";
            }
            
            if (!displayPrompt) {
              if (job.jobType === 'script_analyze') {
                displayPrompt = 'Phân tích kịch bản tập phim';
              } else if (job.jobType === 'script_evaluate') {
                displayPrompt = 'Đánh giá kịch bản tập phim';
              } else {
                displayPrompt = job.jobType || 'Không rõ tác vụ';
              }
            }

            let resultUrl = undefined;
            if (Array.isArray(job.outputUrls) && job.outputUrls.length > 0) {
              resultUrl = job.outputUrls[0];
            } else if (typeof job.outputUrls === 'string') {
              try {
                const str = job.outputUrls;
                if (str.startsWith('{') || str.startsWith('[')) {
                  const parsed = JSON.parse(str);
                  if (Array.isArray(parsed) && parsed.length > 0) {
                    resultUrl = typeof parsed[0] === 'string' ? parsed[0] : JSON.stringify(parsed[0]);
                  } else if (parsed.images && Array.isArray(parsed.images) && parsed.images[0]?.url) {
                    resultUrl = parsed.images[0].url;
                  } else if (parsed.result?.urls && Array.isArray(parsed.result.urls)) {
                    resultUrl = parsed.result.urls[0];
                  } else if (parsed.url) {
                    resultUrl = parsed.url;
                  } else {
                    resultUrl = str;
                  }
                } else {
                  resultUrl = str;
                }
              } catch {
                resultUrl = job.outputUrls;
              }
            } else if (job.output_url) {
              try {
                const str = typeof job.output_url === 'string' ? job.output_url : JSON.stringify(job.output_url);
                if (str.startsWith('{') || str.startsWith('[')) {
                  const parsed = JSON.parse(str);
                  if (Array.isArray(parsed) && parsed.length > 0) {
                    resultUrl = typeof parsed[0] === 'string' ? parsed[0] : JSON.stringify(parsed[0]);
                  } else if (parsed.images && Array.isArray(parsed.images) && parsed.images[0]?.url) {
                    resultUrl = parsed.images[0].url;
                  } else if (parsed.result?.urls && Array.isArray(parsed.result.urls)) {
                    resultUrl = parsed.result.urls[0];
                  } else if (parsed.url) {
                    resultUrl = parsed.url;
                  } else {
                    resultUrl = str;
                  }
                } else {
                  resultUrl = str;
                }
              } catch {
                resultUrl = typeof job.output_url === 'string' ? job.output_url : JSON.stringify(job.output_url);
              }
            }

            if (resultUrl && typeof resultUrl === 'string') {
              if (resultUrl.includes('localhost:5100') || resultUrl.includes('127.0.0.1:5100')) {
                const cleanGflowUrl = (gflowUrl || "https://hub.storymee.com").replace(/\/$/, '');
                resultUrl = resultUrl.replace(/^https?:\/\/(localhost|127\.0\.0\.1):5100/, cleanGflowUrl);
              }
            }

            let mediaType = 'text';
            const lowerType = (job.jobType || '').toLowerCase();
            const lowerUrl = (resultUrl || '').toLowerCase();

            if (
              lowerUrl.includes('video') || 
              lowerUrl.includes('mp4') || 
              lowerUrl.includes('webm') || 
              lowerUrl.includes('avi') || 
              lowerUrl.includes('mov') ||
              lowerType === 'video' || 
              lowerType.includes('video') ||
              lowerType.includes('animation')
            ) {
              mediaType = 'video';
            } else if (
              lowerUrl.includes('image') || 
              lowerUrl.includes('jpg') || 
              lowerUrl.includes('jpeg') || 
              lowerUrl.includes('png') || 
              lowerUrl.includes('webp') || 
              lowerUrl.includes('gif') ||
              lowerType === 'image' || 
              lowerType.includes('image') ||
              lowerType.includes('picture') ||
              lowerType.includes('draw')
            ) {
              mediaType = 'image';
            } else if (
              lowerUrl.includes('audio') || 
              lowerUrl.includes('mp3') || 
              lowerUrl.includes('wav') || 
              lowerUrl.includes('ogg') ||
              lowerType === 'audio' || 
              lowerType.includes('audio')
            ) {
              mediaType = 'audio';
            }

            let extStatus: 'pending' | 'processing' | 'done' | 'failed' = 'pending';
            if (job.status === 'done') extStatus = 'done';
            else if (job.status === 'failed') extStatus = 'failed';
            else if (job.status === 'processing' || job.status === 'queued') extStatus = 'processing';

            const pool = job.pool || job.inputParams?.pool || 'internal';
            const source = job.source || 'api';
            const batchName = job.batchName || job.inputParams?.batchName || undefined;

            const configData = job.config || job.inputParams?.config || {};
            const reqModel = job.model || job.reqModel || configData.model_id || configData.modelId || job.inputParams?.model_id || job.inputParams?.modelId || 'auto';
            const rawRatio = job.aspectRatio || job.reqRatio || configData.aspect_ratio || configData.aspectRatio || job.inputParams?.aspect_ratio || job.inputParams?.aspectRatio || (mediaType === 'video' ? '16:9' : '1:1');
            const ratioDisp = formatRatio(rawRatio);
            const rawDuration = job.reqDuration !== undefined ? job.reqDuration : (configData.duration || configData.duration_sec || configData.durationSec || configData.duration_seconds || job.inputParams?.duration || job.inputParams?.duration_seconds);
            const durationDisp = rawDuration !== undefined ? (rawDuration ? `${rawDuration}s` : '—') : (mediaType === 'video' ? '5s' : '—');

            return {
              id: job.id,
              mediaType: mediaType,
              prompt: displayPrompt,
              provider: job.provider || job.inputParams?.provider || (job.jobType.includes('script_') ? 'LLM_AI' : 'Hub'),
              status: extStatus,
              timestamp: job.createdAt ? new Date(job.createdAt).getTime() : Date.now(),
              resultUrl: resultUrl,
              error: job.errorMessage || undefined,
              projectId: job.inputParams?.actualMeta?.projectId || job.inputParams?.actual_meta?.projectId || job.inputParams?.project_id || job.inputParams?.projectId,
              projectName: job.inputParams?.project_name || job.inputParams?.projectName,
              projectLink: job.inputParams?.project_link || job.inputParams?.projectLink,
              executedBy: job.executed_by || job.inputParams?.executed_by || undefined,
              source: source,
              pool: pool,
              batchName: batchName,
              modelDisp: reqModel,
              ratioDisp: ratioDisp,
              durationDisp: durationDisp,
              inputParams: job.inputParams
            };
          });

          // Gộp thông minh để tránh ghi đè làm mất jobs của các provider khác khi reload/switch tab
          setJobs(prevJobs => {
            const otherProviderJobs = prevJobs.filter(ej => {
              const ejProvider = (ej.provider || '').toUpperCase();
              const selProv = selectedProvider.toUpperCase();
              // Google Flow có hai kiểu provider name tương đương
              if (selProv === 'GFLOW' || selProv === 'GOOGLE_FLOW') {
                return ejProvider !== 'GFLOW' && ejProvider !== 'GOOGLE_FLOW';
              }
              return ejProvider !== selProv;
            });
            const merged = [...mappedJobs, ...otherProviderJobs];
            // Sắp xếp theo thời gian mới nhất lên đầu
            merged.sort((a, b) => b.timestamp - a.timestamp);
            
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
              chrome.storage.local.set({ recent_jobs_list: merged });
            }
            return merged;
          });
        }
      } else {
        console.warn(`[FE Jobs] Fetch jobs failed or empty response`);
      }
    } catch (err: any) {
      console.error(`[FE Jobs] Error fetching jobs:`, err.message);
    } finally {
      setIsFetchingJobs(false);
    }
  };

  // Load configuration and storage variables
  useEffect(() => {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      console.warn("[Universal Ext] Chrome Storage APIs are not available in this environment.");
      return;
    }

    try {
      chrome.storage.local.get([
        "gflowUrl", 
        "workerState", 
        "googleEmail",
        "googleAvatar",
        "oauthToken", 
        "xBrowserValidation", 
        "xClientData",
        "recent_jobs_list",
        "dreamina_execution_mode",
        "dreamina_accounts",
        "picsart_accounts",
        "topview_accounts",
        "gflow_accounts",
        "current_dreamina_email",
        "auto_switch_enabled",
        "hub_api_key",
        "active_emails",
        "hide_low_points",
        "dreamina_api_key",
        "picsart_api_key",
        "topview_api_key",
        "gflow_api_key",
        "workerName",
        "active_executor",
        "rotation_log",
        "selected_provider"
      ], (data: any) => {
        try {
          if (chrome.runtime.lastError) {
            console.warn("[Universal Ext] Error in storage get runtime:", chrome.runtime.lastError.message);
            return;
          }
          if (data) {
            if (data.gflowUrl) {
              setGflowUrl(data.gflowUrl);
            } else {
              setGflowUrl("https://hub.storymee.com");
              chrome.storage.local.set({ gflowUrl: "https://hub.storymee.com" });
            }
            if (data.workerState) setWorkerState(data.workerState);
            if (data.googleEmail) setGoogleEmail(data.googleEmail);
            if (data.googleAvatar) setGoogleAvatar(data.googleAvatar);
            if (data.oauthToken) setOauthToken(data.oauthToken);
            if (data.xBrowserValidation) setXBrowserValidation(data.xBrowserValidation);
            if (data.xClientData) setXClientData(data.xClientData);
            if (data.workerName) setWorkerName(data.workerName);
            if (data.recent_jobs_list) {
              setJobs(Array.isArray(data.recent_jobs_list) ? data.recent_jobs_list : []);
            } else {
              setJobs([]);
            }
            
            // Provider-specific API keys loading
            const loadedKeys = {
              DREAMINA: data.dreamina_api_key || data.hub_api_key || "",
              PICSART: data.picsart_api_key || data.hub_api_key || "",
              TOPVIEW: data.topview_api_key || data.hub_api_key || "",
              GFLOW: data.gflow_api_key || data.hub_api_key || ""
            };
            setProviderApiKeys(loadedKeys);
            

            // Set hubApiKey initially based on default or selected provider
            const selProv = data.selected_provider || 'DREAMINA';
            if (data.selected_provider) setSelectedProvider(data.selected_provider);
            setHubApiKey(loadedKeys[selProv as 'DREAMINA' | 'PICSART' | 'TOPVIEW' | 'GFLOW']);

            if (data.active_emails) setActiveEmails(data.active_emails);
            else if (data.current_dreamina_email) setActiveEmails({ DREAMINA: data.current_dreamina_email });

            if (data.hide_low_points !== undefined) setHideLowPoints(data.hide_low_points);
            if (data.active_executor) setActiveExecutor(data.active_executor);
            if (data.rotation_log) setRotationLog(data.rotation_log);
            
            // Legacy Dreamina options loading
            if (data.dreamina_execution_mode) setDreaminaExecutionMode(data.dreamina_execution_mode);
            if (data.auto_switch_enabled !== undefined) setAutoSwitchEnabled(data.auto_switch_enabled);
            
            // Set 4 provider accounts
            if (data.dreamina_accounts) setDreaminaAccounts(data.dreamina_accounts);
            if (data.picsart_accounts) setPicsartAccounts(data.picsart_accounts);
            if (data.topview_accounts) setTopviewAccounts(data.topview_accounts);
            if (data.gflow_accounts) setGflowAccounts(data.gflow_accounts);

            if (data.current_dreamina_email) setCurrentDreaminaEmail(data.current_dreamina_email);
          }
        } catch (innerErr) {
          console.error("[Universal Ext] Error processing loaded storage data:", innerErr);
        }
      });
    } catch (err) {
      console.error("[Universal Ext] Failed to query chrome.storage.local:", err);
    }

    // Listen to changes in chrome.storage
    const handleStorageChange = (changes: any, areaName: string) => {
      if (areaName === "local" && changes) {
        try {
          if (changes.gflowUrl) setGflowUrl(changes.gflowUrl.newValue);
          if (changes.workerState) setWorkerState(changes.workerState.newValue);
          if (changes.googleEmail) setGoogleEmail(changes.googleEmail.newValue);
          if (changes.googleAvatar) setGoogleAvatar(changes.googleAvatar.newValue);
          if (changes.oauthToken) setOauthToken(changes.oauthToken.newValue);
          if (changes.xBrowserValidation) setXBrowserValidation(changes.xBrowserValidation.newValue);
          if (changes.xClientData) setXClientData(changes.xClientData.newValue);
          if (changes.selected_provider) {
            setSelectedProvider(changes.selected_provider.newValue);
            chrome.storage.local.get([
              "hub_api_key", "dreamina_api_key", "picsart_api_key", "topview_api_key", "gflow_api_key"
            ]).then((data: any) => {
              const keys = {
                DREAMINA: data.dreamina_api_key || data.hub_api_key || "",
                PICSART: data.picsart_api_key || data.hub_api_key || "",
                TOPVIEW: data.topview_api_key || data.hub_api_key || "",
                GFLOW: data.gflow_api_key || data.hub_api_key || ""
              };
              setHubApiKey(keys[changes.selected_provider.newValue as 'DREAMINA' | 'PICSART' | 'TOPVIEW' | 'GFLOW'] || "");
            });
          }
          if (changes.recent_jobs_list) {
            setJobs(Array.isArray(changes.recent_jobs_list.newValue) ? changes.recent_jobs_list.newValue : []);
          }
          
          if (changes.hub_api_key) {

          }
          // Centralized live updates
          if (changes.hub_api_key || changes.dreamina_api_key || changes.picsart_api_key || changes.topview_api_key || changes.gflow_api_key) {
            chrome.storage.local.get([
              "hub_api_key", "dreamina_api_key", "picsart_api_key", "topview_api_key", "gflow_api_key"
            ]).then((data: any) => {
              setProviderApiKeys({
                DREAMINA: data.dreamina_api_key || data.hub_api_key || "",
                PICSART: data.picsart_api_key || data.hub_api_key || "",
                TOPVIEW: data.topview_api_key || data.hub_api_key || "",
                GFLOW: data.gflow_api_key || data.hub_api_key || ""
              });
            });
          }
          if (changes.active_emails) setActiveEmails(changes.active_emails.newValue || {});
          if (changes.hide_low_points) setHideLowPoints(changes.hide_low_points.newValue || false);
          if (changes.active_executor) setActiveExecutor(changes.active_executor.newValue || null);
          if (changes.rotation_log) setRotationLog(changes.rotation_log.newValue || []);

          // Live updates for 4 provider accounts
          if (changes.dreamina_accounts) setDreaminaAccounts(changes.dreamina_accounts.newValue || []);
          if (changes.picsart_accounts) setPicsartAccounts(changes.picsart_accounts.newValue || []);
          if (changes.topview_accounts) setTopviewAccounts(changes.topview_accounts.newValue || []);
          if (changes.gflow_accounts) setGflowAccounts(changes.gflow_accounts.newValue || []);

          // Legacy Dreamina live updates
          if (changes.dreamina_execution_mode) setDreaminaExecutionMode(changes.dreamina_execution_mode.newValue);
          if (changes.current_dreamina_email) setCurrentDreaminaEmail(changes.current_dreamina_email.newValue || "");
          if (changes.auto_switch_enabled) setAutoSwitchEnabled(changes.auto_switch_enabled.newValue !== false);
        } catch (innerErr) {
          console.error("[Universal Ext] Error processing storage changes:", innerErr);
        }
      }
    };

    // Runtime message listener
    const handleRuntimeMessage = (message: any) => {
      if (message) {
        try {
          if (message.type === "WS_STATUS") {
            setWorkerState(message.status);
          }
          if (message.type === "JOB_UPDATED") {
            setJobs(Array.isArray(message.list) ? message.list : []);
          }
          if (message.type === "BG_LOG") {
            const prefix = `[BG-${message.logType.toUpperCase()}]`;
            if (message.logType === 'error') {
              console.error(prefix, message.message);
            } else if (message.logType === 'warn') {
              console.warn(prefix, message.message);
            } else {
              console.log(prefix, message.message);
            }
          }
        } catch (innerErr) {
          console.error("[Universal Ext] Error processing runtime message:", innerErr);
        }
      }
    };

    try {
      chrome.storage.onChanged.addListener(handleStorageChange);
    } catch (err) {
      console.error("[Universal Ext] Failed to add storage change listener:", err);
    }

    try {
      chrome.runtime.onMessage.addListener(handleRuntimeMessage);
    } catch (err) {
      console.error("[Universal Ext] Failed to add runtime message listener:", err);
    }

    return () => {
      try {
        chrome.storage.onChanged.removeListener(handleStorageChange);
      } catch (e) {}
      try {
        chrome.runtime.onMessage.removeListener(handleRuntimeMessage);
      } catch (e) {}
    };
  }, []);

  // Lifeline connection to keep service worker alive
  useEffect(() => {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.connect) return;
    
    console.log("[Universal Ext] Opening lifeline port...");
    const port = chrome.runtime.connect({ name: "universal-lifeline" });
    
    const interval = setInterval(() => {
      try {
        port.postMessage({ type: "ping" });
      } catch (e) {
        console.warn("[Universal Ext] Lifeline port ping failed:", e);
      }
    }, 10000);
    
    return () => {
      clearInterval(interval);
      try {
        port.disconnect();
      } catch (e) {}
    };
  }, []);

  const getLowPointsThreshold = (provider: string): number => {
    const up = provider.toUpperCase();
    if (up === 'DREAMINA') return 4;
    if (up === 'PICSART') return 1;
    if (up === 'TOPVIEW') return 1;
    return 1;
  };

  const getAccountTierBadge = (acc: any, provider: string) => {
    const provUpper = provider.toUpperCase();
    if (provUpper === 'GFLOW') {
      const isUltra = acc.points >= 1000 || acc.email.toLowerCase().includes('ultra') || acc.email.toLowerCase().includes('labs') || acc.cookieStr?.includes('ultra');
      if (isUltra) {
        return (
          <span className="text-[9px] font-extrabold uppercase tracking-wider bg-gradient-to-r from-amber-500 to-rose-500 text-white px-2 py-0.5 rounded-full shadow-sm">
            Google Ultra
          </span>
        );
      }
      return (
        <span className="text-[9px] font-extrabold uppercase tracking-wider bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">
          Google Standard
        </span>
      );
    }
    
    if (provUpper === 'DREAMINA') {
      const isVip = acc.points >= 900 || acc.email.toLowerCase().includes('pro') || acc.email.toLowerCase().includes('vip') || acc.pool === 'vip';
      if (isVip) {
        return (
          <span className="text-[9px] font-extrabold uppercase tracking-wider bg-gradient-to-r from-violet-600 to-indigo-600 text-white px-2 py-0.5 rounded-full shadow-sm">
            Dreamina VIP
          </span>
        );
      }
      return (
        <span className="text-[9px] font-extrabold uppercase tracking-wider bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">
          Dreamina Free
        </span>
      );
    }

    if (provUpper === 'PICSART') {
      const isPro = acc.points >= 50 || acc.email.toLowerCase().includes('pro') || acc.email.toLowerCase().includes('gold');
      if (isPro) {
        return (
          <span className="text-[9px] font-extrabold uppercase tracking-wider bg-gradient-to-r from-amber-500 to-orange-500 text-white px-2 py-0.5 rounded-full shadow-sm">
            Picsart Gold
          </span>
        );
      }
      return (
        <span className="text-[9px] font-extrabold uppercase tracking-wider bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">
          Picsart Free
        </span>
      );
    }

    if (provUpper === 'TOPVIEW') {
      const isPro = acc.points >= 10 || acc.email.toLowerCase().includes('pro') || acc.email.toLowerCase().includes('vip');
      if (isPro) {
        return (
          <span className="text-[9px] font-extrabold uppercase tracking-wider bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-2 py-0.5 rounded-full shadow-sm">
            TopView Pro
          </span>
        );
      }
      return (
        <span className="text-[9px] font-extrabold uppercase tracking-wider bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">
          TopView Standard
        </span>
      );
    }
    
    return null;
  };

  // Watch selectedProvider to load correct provider accounts from chrome storage local
  useEffect(() => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      const storeKey = `${selectedProvider.toLowerCase()}_accounts`;
      chrome.storage.local.get([storeKey]).then((data) => {
        const stored = (data as any)[storeKey];
        const list = Array.isArray(stored) ? stored : [];
        const provUpper = selectedProvider.toUpperCase();
        if (provUpper === 'DREAMINA') setDreaminaAccounts(list);
        else if (provUpper === 'PICSART') setPicsartAccounts(list);
        else if (provUpper === 'TOPVIEW') setTopviewAccounts(list);
        else if (provUpper === 'GFLOW') setGflowAccounts(list);
      }).catch((err) => {
        console.warn(`[FE] Failed to get ${storeKey} from local storage:`, err);
      });
    }
    
    // Update hubApiKey input value to match the selected provider's API key
    const targetKey = providerApiKeys[selectedProvider.toUpperCase()] || "";
    setHubApiKey(targetKey);
    
    // Auto-sync fresh accounts list from Hub when provider tab changes
    const apiToken = targetKey || hubApiKey || "sk-storymee-pgpgdnzsy6";
    if (apiToken) {
      syncAccounts(selectedProvider);
    }
  }, [selectedProvider, providerApiKeys]);

  // Poll jobs when History tab or dashboard is active
  useEffect(() => {
    let interval: any;
    fetchJobsFromHub();
    interval = setInterval(() => {
      fetchJobsFromHub();
    }, 10000);
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [gflowUrl, hubApiKey, selectedProvider]);

  const handleConnectWs = () => {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      console.warn("[Universal Ext] Chrome runtime Messaging API is not available.");
      return;
    }
    try {
      chrome.runtime.sendMessage({
        action: "CONNECT_WS",
        payload: { gflowUrl: gflowUrl }
      }, (res) => {
        if (chrome.runtime.lastError) {
          console.warn("[Universal Ext] Reconnect message error:", chrome.runtime.lastError.message);
          return;
        }
        if (res && res.success) {
          console.log("[Universal Ext] Reconnect message sent successfully.");
        }
      });
    } catch (err) {
      console.error("[Universal Ext] Failed to send CONNECT_WS message:", err);
    }
  };

  // Centralized Multi-Account Handlers
  const syncAccounts = async (provider: string) => {
    setIsSyncingAccounts(true);
    try {
      const apiClient = await getHubApiClient();
      console.log(`[FE Sync] Fetching ${provider} accounts via API Client`);
      const resJson = await apiClient.get(`/accounts?provider=${provider.toUpperCase()}&decrypt=true`);

      if (resJson && resJson.data) {
        const accountsRaw = resJson.data || resJson.accounts || [];
        if (Array.isArray(accountsRaw)) {
          const accounts = accountsRaw.map((acc: any) => {
            let cookieStrVal = "";
            if (typeof acc.cookies === 'string') {
              cookieStrVal = acc.cookies;
            } else if (acc.cookies && typeof acc.cookies === 'object') {
              cookieStrVal = Array.isArray(acc.cookies) ? acc.cookies.map((c: any) => `${c.name}=${c.value}`).join('; ') : JSON.stringify(acc.cookies);
            } else {
              cookieStrVal = acc.cookieStr || "";
            }

            const ptsVal = Math.max(
              acc.points !== undefined && acc.points !== null ? Number(acc.points) : 0,
              acc.credits !== undefined && acc.credits !== null ? Number(acc.credits) : 0,
              acc.tokenBalance !== undefined && acc.tokenBalance !== null ? Number(acc.tokenBalance) : 0
            );
            const threshold = getLowPointsThreshold(provider);
            return {
              email: acc.email,
              cookieStr: cookieStrVal,
              points: ptsVal,
              status: acc.status || (ptsVal >= threshold ? "ACTIVE" : "LOW_CREDIT"),
              lastChecked: acc.lastChecked || acc.last_checked || null
            };
          });
          
          const provUpper = provider.toUpperCase();
          if (provUpper === 'DREAMINA') setDreaminaAccounts(accounts);
          else if (provUpper === 'PICSART') setPicsartAccounts(accounts);
          else if (provUpper === 'TOPVIEW') setTopviewAccounts(accounts);
          else if (provUpper === 'GFLOW') setGflowAccounts(accounts);
          
          // Store accounts for this provider in storage
          const storeKey = `${provider.toLowerCase()}_accounts`;
          await chrome.storage.local.set({ [storeKey]: accounts });
          
          // Auto-select active account if not set
          const activeForProv = activeEmails[provider.toUpperCase()] || "";
          if (!activeForProv && accounts.length > 0) {
            const threshold = getLowPointsThreshold(provider);
            const firstActive = accounts.find((a: any) => a.points >= threshold) || accounts[0];
            const updatedActive = { ...activeEmails, [provider.toUpperCase()]: firstActive.email };
            setActiveEmails(updatedActive);
            await chrome.storage.local.set({ active_emails: updatedActive });
            
            if (provider.toUpperCase() === 'DREAMINA') {
              await chrome.storage.local.set({ current_dreamina_email: firstActive.email });
            }
          }
        }
      }
    } catch (err: any) {
      console.error(`[FE Sync] Error syncing accounts for ${provider}:`, err.message);
    } finally {
      setIsSyncingAccounts(false);
    }
  };

  const syncAllAccounts = async () => {
    await Promise.all([
      syncAccounts('DREAMINA'),
      syncAccounts('PICSART'),
      syncAccounts('TOPVIEW'),
      syncAccounts('GFLOW')
    ]);
  };

  const handleSwitchAccount = async (provider: string, email: string, cookieStr: string) => {
    const providerUpper = provider.toUpperCase();
    setVerifyingEmail(email);
    
    // Save locally
    const updatedActive = { ...activeEmails, [providerUpper]: email };
    setActiveEmails(updatedActive);
    await chrome.storage.local.set({ active_emails: updatedActive });
    
    if (providerUpper === 'DREAMINA') {
      await chrome.storage.local.set({ current_dreamina_email: email });
    }
    
    // Trigger cookies injection and automatic points verification in the background script
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({
        action: "SWITCH_ACCOUNT",
        payload: { provider: providerUpper, email, cookieStr }
      }, (res) => {
        setVerifyingEmail(null);
        if (chrome.runtime.lastError) {
          console.warn("[FE Sync] Switch account message runtime error:", chrome.runtime.lastError.message);
          return;
        }
        
        if (res && res.success) {
          console.log(`[FE Sync] Successfully switched active account for ${providerUpper} to ${email}. Points: ${res.points}`);
          
          // Refresh list from local storage cache to reflect new points & status
          const storeKey = `${provider.toLowerCase()}_accounts`;
          chrome.storage.local.get([storeKey]).then((data: any) => {
            const list = data[storeKey] || [];
            if (providerUpper === 'DREAMINA') setDreaminaAccounts(list);
            else if (providerUpper === 'PICSART') setPicsartAccounts(list);
            else if (providerUpper === 'TOPVIEW') setTopviewAccounts(list);
            else if (providerUpper === 'GFLOW') setGflowAccounts(list);
          });
        } else {
          console.error(`[FE Sync] Failed to switch or verify account:`, res?.error);
        }
      });
    }
  };

  const onSwitchAccountFromJob = async (provider: string, email: string) => {
    const providerUpper = provider.toUpperCase();
    let accList: any[] = [];
    if (providerUpper === 'DREAMINA') accList = dreaminaAccounts;
    else if (providerUpper === 'PICSART') accList = picsartAccounts;
    else if (providerUpper === 'TOPVIEW') accList = topviewAccounts;
    else if (providerUpper === 'GFLOW') accList = gflowAccounts;

    const acc = accList.find(a => a.email.toLowerCase() === email.toLowerCase());
    if (acc) {
      await handleSwitchAccount(provider, acc.email, acc.cookieStr);
      alert(`Đã switch sang tài khoản ${acc.email} thành công!`);
    } else {
      alert(`Không tìm thấy cookie/tài khoản cho ${email} trong extension. Vui lòng thêm/sync tài khoản này trước.`);
    }
  };


  const handleReleaseAccount = async (provider: string, email: string) => {
    const providerUpper = provider.toUpperCase();
    const apiClient = await getHubApiClient();
    
    try {
      await apiClient.post('/accounts/unlock', {
        provider: providerUpper, 
        email: email, 
        workerName: workerName || "universal-director" 
      });
      if (providerUpper === 'DREAMINA') {
        await apiClient.post('/extension/dreamina-accounts/lock', { email, action: 'unlock' }).catch(() => {});
      }
    } catch (lockErr) {
      console.error("[FE Sync] Unlock error:", lockErr);
    }

    // Clear local active state
    const updatedActive = { ...activeEmails, [providerUpper]: "" };
    setActiveEmails(updatedActive);
    await chrome.storage.local.set({ active_emails: updatedActive });
    
    if (providerUpper === 'DREAMINA') {
      await chrome.storage.local.set({ current_dreamina_email: "" });
    }
    
    syncAccounts(provider);
  };

  const handleSwitchSelectedProvider = async (prov: 'DREAMINA' | 'PICSART' | 'TOPVIEW' | 'GFLOW') => {
    setSelectedProvider(prov);
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await chrome.storage.local.set({ selected_provider: prov });
      chrome.runtime.sendMessage({ type: "FORCE_RECONNECT_WS" }).catch(() => {});
    }
  };

  const handleSaveHubApiKey = async () => {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      const storageKey = `${selectedProvider.toLowerCase()}_api_key`;
      await chrome.storage.local.set({ [storageKey]: hubApiKey });
      
      // Update local state
      const updatedKeys = { ...providerApiKeys, [selectedProvider.toUpperCase()]: hubApiKey };
      setProviderApiKeys(updatedKeys);

      // Backwards compatible hub_api_key update
      await chrome.storage.local.set({ hub_api_key: hubApiKey });
      
      // Save workerName
      if (workerName.trim()) {
        await chrome.storage.local.set({ workerName: workerName.trim() });
      }
      
      // Sync immediately
      syncAccounts(selectedProvider);

      // Force reconnect WS immediately to apply the new API Key
      chrome.runtime.sendMessage({ type: "FORCE_RECONNECT_WS" }).catch(() => {});
    }
  };

  const handleRequestMoreAccounts = async () => {
    try {
      const apiClient = await getHubApiClient(false);
      console.log(`[FE Accounts] Requesting more slots for ${selectedProvider}...`);
      
      const resJson = await apiClient.post(`/v1/worker/${selectedProvider.toLowerCase()}/request-more`, {});
      if (resJson && resJson.success) {
        alert(`Đã gửi yêu cầu cấp thêm tài khoản ${selectedProvider} thành công!`);
      } else {
        alert(`Yêu cầu thất bại. Vui lòng kiểm tra lại cấu hình.`);
      }
    } catch (err: any) {
      alert(`Lỗi khi gửi yêu cầu: ${err.message}`);
    }
  };

  const handleToggleExecutionMode = async (mode: 'extension' | 'headless') => {
    setDreaminaExecutionMode(mode);
    await chrome.storage.local.set({ dreamina_execution_mode: mode });
  };

  const handleToggleAutoSwitch = async (enabled: boolean) => {
    setAutoSwitchEnabled(enabled);
    await chrome.storage.local.set({ auto_switch_enabled: enabled });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  // Filter and search logic for jobs
  const filteredJobs = jobs.filter(job => {
    const matchStatus = jobStatusFilter === 'all' 
      ? true 
      : jobStatusFilter === 'processing' 
        ? (job.status === 'processing' || job.status === 'pending')
        : job.status === jobStatusFilter;
    const matchProvider = jobProviderFilter === 'ALL'
      ? true
      : (job.provider || '').toUpperCase() === jobProviderFilter;
    const matchSearch = job.prompt.toLowerCase().includes(jobSearchQuery.toLowerCase()) || 
                        (job.executedBy && job.executedBy.toLowerCase().includes(jobSearchQuery.toLowerCase())) ||
                        job.id.toLowerCase().includes(jobSearchQuery.toLowerCase());
    return matchStatus && matchProvider && matchSearch;
  });

  const totalJobsCount = jobs.filter(j => jobProviderFilter === 'ALL' ? true : (j.provider || '').toUpperCase() === jobProviderFilter).length;
  const processingJobsCount = jobs.filter(j => (j.status === 'processing' || j.status === 'pending') && (jobProviderFilter === 'ALL' ? true : (j.provider || '').toUpperCase() === jobProviderFilter)).length;
  const doneJobsCount = jobs.filter(j => j.status === 'done' && (jobProviderFilter === 'ALL' ? true : (j.provider || '').toUpperCase() === jobProviderFilter)).length;
  const failedJobsCount = jobs.filter(j => j.status === 'failed' && (jobProviderFilter === 'ALL' ? true : (j.provider || '').toUpperCase() === jobProviderFilter)).length;

  // ----------------------------------------  // 1. SIDEPANEL GIAO DIỆN TỐI GIẢN
  if (isSidepanel) {
    // We only support 2 tabs in sidepanel: 'dashboard' (Giám sát) and 'accounts' (Cài đặt)
    // Force active tab to accounts/Cài đặt to disable job monitoring in sidepanel
    let sidepanelActiveTab = 'accounts' as any;

    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans relative select-none">
        {/* Background neon glows */}
        <div className="absolute top-[-10%] left-[-20%] w-[60%] h-[30%] bg-purple-900/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-[-10%] right-[-20%] w-[60%] h-[30%] bg-blue-900/10 rounded-full blur-[100px] pointer-events-none" />

        {/* Minimal Header */}
        <header className="border-b border-slate-800/80 bg-slate-900/40 backdrop-blur-md sticky top-0 z-50 px-3 py-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-gradient-to-tr from-purple-600 to-indigo-600 rounded-lg shadow-md shadow-indigo-500/20">
              <Sparkles className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <h1 className="text-xs font-bold bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                Universal AI
              </h1>
              <p className="text-[8px] text-slate-400">StoryMee Worker</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {getRouteBadge()}
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold backdrop-blur-sm border ${
              workerState === 'ONLINE' 
                ? 'bg-emerald-955/40 border-emerald-500/35 text-emerald-400' 
                : workerState === 'CONNECTING'
                ? 'bg-amber-955/40 border-amber-500/35 text-amber-400 animate-pulse'
                : 'bg-rose-955/40 border-rose-500/35 text-rose-400'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${
                workerState === 'ONLINE' ? 'bg-emerald-400 animate-pulse' : workerState === 'CONNECTING' ? 'bg-amber-400' : 'bg-rose-400'
              }`} />
              {workerState}
            </span>

            <button 
              onClick={openDashboard}
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-all"
              title="Mở Dashboard"
            >
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>
        </header>

        {/* Sidepanel Body */}
        <main className="flex-1 overflow-y-auto p-3 space-y-3">
          {sidepanelActiveTab === 'dashboard' && (
            <>
              {/* WS Status & Route Badge */}
              <div className="bg-slate-900/40 border border-slate-850 rounded-xl p-3 flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Kết nối:</span>
                <div className="flex items-center gap-2">
                  {getRouteBadge()}
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold backdrop-blur-sm border ${
                    workerState === 'ONLINE' 
                      ? 'bg-emerald-955/40 border-emerald-500/35 text-emerald-400' 
                      : workerState === 'CONNECTING'
                      ? 'bg-amber-955/40 border-amber-500/35 text-amber-400 animate-pulse'
                      : 'bg-rose-955/40 border-rose-500/35 text-rose-400'
                  }`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${
                      workerState === 'ONLINE' ? 'bg-emerald-400 animate-pulse' : workerState === 'CONNECTING' ? 'bg-amber-400' : 'bg-rose-400'
                    }`} />
                    {workerState}
                  </span>
                </div>
              </div>

              {/* Gateway URL Display */}
              <div className="text-[10px] text-slate-400 font-mono break-all px-1">
                Gateway: <span className="text-indigo-400">{gflowUrl}</span>
              </div>

              {/* Stats 2x2 Table */}
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-slate-900/30 border border-slate-850/60 rounded-lg p-2 text-center">
                  <p className="text-[9px] text-slate-500 font-bold uppercase">Tổng Job</p>
                  <p className="text-sm font-bold text-slate-200">{jobs.length}</p>
                </div>
                <div className="bg-slate-900/30 border border-slate-850/60 rounded-lg p-2 text-center">
                  <p className="text-[9px] text-slate-505 font-bold uppercase text-amber-400">Đang chạy</p>
                  <p className="text-sm font-bold text-amber-400">{processingJobsCount}</p>
                </div>
                <div className="bg-slate-900/30 border border-slate-850/60 rounded-lg p-2 text-center">
                  <p className="text-[9px] text-slate-505 font-bold uppercase text-emerald-400">Thành công</p>
                  <p className="text-sm font-bold text-emerald-400">{doneJobsCount}</p>
                </div>
                <div className="bg-slate-900/30 border border-slate-850/60 rounded-lg p-2 text-center">
                  <p className="text-[9px] text-slate-505 font-bold uppercase text-rose-450">Lỗi</p>
                  <p className="text-sm font-bold text-rose-450">{failedJobsCount}</p>
                </div>
              </div>

              {/* Active Jobs */}
              {(() => {
                const activeJobs = jobs.filter(j => j.status === 'processing' || j.status === 'pending');
                return (
                  <section className="bg-slate-900/40 border border-slate-850 rounded-xl p-3 space-y-2">
                    <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Active Jobs ({activeJobs.length})
                    </h3>
                    {activeJobs.length === 0 ? (
                      <p className="text-[10px] text-slate-500 italic text-center py-2">Không có job đang chạy</p>
                    ) : (
                      <div className="space-y-1.5">
                        {activeJobs.map(job => (
                          <div key={job.id} className="bg-slate-950/60 border border-slate-900 rounded-lg p-2 space-y-1">
                            <div className="flex items-center justify-between text-[9px]">
                              <span className="text-slate-500 font-mono">ID: {job.id.substring(0, 6)}...</span>
                              <span className="font-bold px-1.5 py-0.2 rounded uppercase bg-amber-955/80 text-amber-400 border border-amber-900/30 animate-pulse">
                                {job.status}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-350 truncate italic">"{job.prompt}"</p>
                            {job.executedBy && (
                              <p className="text-[8px] text-slate-500 truncate">Thực thi: {job.executedBy}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </section>
                );
              })()}

              {/* 3 Last Jobs */}
              {(() => {
                const completedJobs = jobs.filter(j => j.status === 'done' || j.status === 'failed').slice(0, 3);
                return (
                  <section className="bg-slate-900/40 border border-slate-850 rounded-xl p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                        Jobs gần đây
                      </h3>
                      <button 
                        onClick={fetchJobsFromHub}
                        disabled={isFetchingJobs}
                        className="p-1 rounded bg-slate-800 border border-slate-700 hover:border-slate-650 transition-all text-slate-400 hover:text-slate-205"
                      >
                        <RefreshCw className={`w-2.5 h-2.5 ${isFetchingJobs ? 'animate-spin text-indigo-400' : ''}`} />
                      </button>
                    </div>

                    {completedJobs.length === 0 ? (
                      <p className="text-[10px] text-slate-505 italic text-center py-2">Không có task nào</p>
                    ) : (
                      <div className="space-y-1.5">
                        {completedJobs.map(job => (
                          <div key={job.id} className="bg-slate-950/60 border border-slate-900 rounded-lg p-2 space-y-1">
                            <div className="flex items-center justify-between text-[9px]">
                              <span className="text-slate-505 font-mono">ID: {job.id.substring(0, 6)}...</span>
                              <span className={`font-bold px-1.5 py-0.2 rounded uppercase ${
                                job.status === 'done' ? 'bg-emerald-955/80 text-emerald-400 border border-emerald-900/30' :
                                'bg-rose-955/80 text-rose-450 border border-rose-900/30'
                              }`}>
                                {job.status}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-350 truncate italic">"{job.prompt}"</p>
                            {job.executedBy && (
                              <p className="text-[8px] text-slate-500 truncate">Thực thi: {job.executedBy}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </section>
                );
              })()}
            </>
          )}

          {sidepanelActiveTab === 'accounts' && (
            <div className="space-y-3">
              {/* Google Identity Captured Badge */}
              {googleEmail && (
                <div className="flex items-center gap-2 bg-slate-950/40 p-2 rounded-lg border border-slate-900">
                  {googleAvatar ? (
                    <img src={googleAvatar} alt="Google" className="w-5 h-5 rounded-full border border-purple-500/20" />
                  ) : (
                    <User className="w-3.5 h-3.5 text-slate-500" />
                  )}
                  <span className="text-[10px] text-slate-400 truncate max-w-[180px]">{googleEmail}</span>
                  <CheckCircle className="w-3 h-3 text-emerald-400 shrink-0" />
                </div>
              )}

              {/* Worker Name Config */}
              <section className="bg-slate-900/40 border border-slate-850 rounded-xl p-3 space-y-2">
                <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Cpu className="w-3 h-3 text-purple-400" />
                  Tên Worker Này
                </h3>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={workerName}
                    onChange={(e) => setWorkerName(e.target.value)}
                    placeholder="Studio-PC, Worker-1..."
                    className="flex-1 bg-slate-950 border border-slate-800 focus:border-violet-500 focus:ring-1 focus:ring-violet-500 text-xs rounded-lg px-2.5 py-1.5 text-slate-200 outline-none placeholder-slate-650"
                  />
                  <button
                    onClick={async () => {
                      if (workerName.trim() && typeof chrome !== 'undefined' && chrome.storage) {
                        await chrome.storage.local.set({ workerName: workerName.trim() });
                        chrome.runtime.sendMessage({ type: "FORCE_RECONNECT_WS" }).catch(() => {});
                        alert("Đã lưu tên worker và khởi động lại WebSocket!");
                      }
                    }}
                    className="bg-violet-650 hover:bg-violet-500 active:scale-95 text-white font-bold text-[10px] px-3 rounded-lg transition-all"
                  >
                    Lưu
                  </button>
                </div>
              </section>

              {/* Gateway Connection Config */}
              <section className="bg-slate-900/40 border border-slate-850 rounded-xl p-3 space-y-2">
                <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Settings className="w-3 h-3 text-indigo-400" />
                  Gateway Connection
                </h3>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={gflowUrl} 
                    onChange={(e) => setGflowUrl(e.target.value)} 
                    placeholder="https://hub.storymee.com" 
                    className="flex-1 bg-slate-950 border border-slate-800 focus:border-indigo-505 focus:ring-1 focus:ring-indigo-550 text-xs rounded-lg px-2.5 py-1.5 text-slate-202 outline-none"
                  />
                  <button
                    onClick={async () => {
                      if (gflowUrl.trim() && typeof chrome !== 'undefined' && chrome.storage) {
                        await chrome.storage.local.set({ gflowUrl: gflowUrl.trim() });
                        chrome.runtime.sendMessage({ type: "FORCE_RECONNECT_WS" }).catch(() => {});
                        alert("Đã lưu Gateway URL và kết nối lại!");
                      }
                    }}
                    className="bg-indigo-650 hover:bg-indigo-600 active:scale-95 text-white font-bold text-[10px] px-3 rounded-lg transition-all"
                  >
                    Lưu
                  </button>
                </div>
                <div className="grid grid-cols-4 gap-1.5 pt-0.5">
                  <button
                    onClick={() => {
                      setGflowUrl("http://localhost:5100");
                      if (typeof chrome !== 'undefined' && chrome.storage) {
                        chrome.storage.local.set({ gflowUrl: "http://localhost:5100" }).then(() => {
                          chrome.runtime.sendMessage({ type: "FORCE_RECONNECT_WS" }).catch(() => {});
                        });
                      }
                    }}
                    className="bg-slate-955 hover:bg-slate-900 border border-slate-850 text-[9px] text-emerald-400 py-1 rounded font-bold transition-all text-center"
                  >
                    Local
                  </button>
                  <button
                    onClick={() => {
                      setGflowUrl("https://dev-hub.storymee.com");
                      if (typeof chrome !== 'undefined' && chrome.storage) {
                        chrome.storage.local.set({ gflowUrl: "https://dev-hub.storymee.com" }).then(() => {
                          chrome.runtime.sendMessage({ type: "FORCE_RECONNECT_WS" }).catch(() => {});
                        });
                      }
                    }}
                    className="bg-slate-955 hover:bg-slate-900 border border-slate-850 text-[9px] text-blue-400 py-1 rounded font-bold transition-all text-center"
                  >
                    Dev Hub
                  </button>
                  <button
                    onClick={() => {
                      setGflowUrl("http://173.249.19.167:5100");
                      if (typeof chrome !== 'undefined' && chrome.storage) {
                        chrome.storage.local.set({ gflowUrl: "http://173.249.19.167:5100" }).then(() => {
                          chrome.runtime.sendMessage({ type: "FORCE_RECONNECT_WS" }).catch(() => {});
                        });
                      }
                    }}
                    className="bg-slate-955 hover:bg-slate-900 border border-slate-850 text-[9px] text-amber-500 py-1 rounded font-bold transition-all text-center"
                  >
                    VPS
                  </button>
                  <button
                    onClick={() => {
                      setGflowUrl("https://hub.storymee.com");
                      if (typeof chrome !== 'undefined' && chrome.storage) {
                        chrome.storage.local.set({ gflowUrl: "https://hub.storymee.com" }).then(() => {
                          chrome.runtime.sendMessage({ type: "FORCE_RECONNECT_WS" }).catch(() => {});
                        });
                      }
                    }}
                    className="bg-slate-955 hover:bg-slate-900 border border-slate-850 text-[9px] text-purple-400 py-1 rounded font-bold transition-all text-center"
                  >
                    Prod Hub
                  </button>
                </div>
              </section>

              {/* Hub API & Decryption Key */}
              <section className="bg-slate-900/40 border border-slate-850 rounded-xl p-3 space-y-2">
                <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Lock className="w-3 h-3 text-emerald-400" />
                  Hub Decryption key ({selectedProvider})
                </h3>
                <div className="relative">
                  <input
                    type={showApiKey ? "text" : "password"}
                    value={hubApiKey}
                    onChange={(e) => setHubApiKey(e.target.value)}
                    placeholder="sk-storymee-..."
                    className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-xs font-mono rounded-lg pl-2.5 pr-8 py-1.5 text-slate-300 outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowApiKey(!showApiKey)}
                    className="absolute right-2.5 top-1.5 text-slate-500 hover:text-slate-300 text-[10px] font-bold"
                  >
                    {showApiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <button
                  onClick={handleSaveHubApiKey}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold text-[10px] py-1.5 rounded-lg transition-all"
                >
                  Lưu & Đồng bộ Accounts
                </button>
              </section>

              {/* Active Providers List */}
              <section className="bg-slate-900/40 border border-slate-850 rounded-xl p-3 space-y-2">
                <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider pb-1 border-b border-slate-800/40">
                  Providers Active Status
                </h3>
                <div className="space-y-1.5">
                  {(['DREAMINA', 'PICSART', 'TOPVIEW', 'GFLOW'] as const).map(provider => {
                    const activeEmail = provider === 'DREAMINA' ? activeDreaminaEmail : (activeEmails[provider] || "");
                    const list = provider === 'DREAMINA' ? dreaminaAccounts :
                                 provider === 'PICSART' ? picsartAccounts :
                                 provider === 'TOPVIEW' ? topviewAccounts :
                                 gflowAccounts;
                    const activeAcc = list.find(a => a.email.toLowerCase() === activeEmail.toLowerCase());
                    const points = activeAcc ? activeAcc.points : 0;
                    
                    return (
                      <div key={provider} className="flex items-center justify-between text-[11px] bg-slate-950/40 p-1.5 rounded-lg border border-slate-900">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className={`w-1.5 h-1.5 rounded-full ${activeEmail ? 'bg-emerald-400' : 'bg-slate-600'}`} />
                          <span className="font-semibold text-slate-350">{provider === 'GFLOW' ? 'Google Flow' : provider}</span>
                        </div>
                        <div className="flex items-center gap-2 min-w-0 text-right">
                          <span className="text-[10px] text-slate-400 truncate max-w-[110px]" title={activeEmail}>
                            {activeEmail || "chưa switch"}
                          </span>
                          {activeEmail && (
                            <span className="text-[8px] font-extrabold px-1.5 py-0.2 bg-indigo-955/80 text-indigo-400 border border-indigo-900/40 rounded">
                              {points} P
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>

              {/* Provider Quick Switcher Tabs & Filter */}
              <div className="space-y-2">
                <div className="flex p-1 bg-slate-900/60 border border-slate-855 rounded-lg gap-0.5">
                  {(['DREAMINA', 'PICSART', 'TOPVIEW', 'GFLOW'] as const).map(prov => {
                    const isSel = selectedProvider === prov;
                    return (
                      <button
                        key={prov}
                        onClick={() => handleSwitchSelectedProvider(prov)}
                        className={`flex-1 py-1 text-[9px] font-extrabold uppercase rounded transition-all ${
                          isSel 
                            ? 'bg-indigo-650 text-white shadow-sm border border-indigo-500/20' 
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {prov === 'GFLOW' ? 'G' : prov.substring(0, 4)}
                      </button>
                    );
                  })}
                </div>
                <div className="flex items-center gap-1.5 justify-end">
                  <input
                    type="checkbox"
                    id="hide-low-pts-side"
                    checked={hideLowPoints}
                    onChange={(e) => {
                      setHideLowPoints(e.target.checked);
                      chrome.storage.local.set({ hide_low_points: e.target.checked });
                    }}
                    className="rounded bg-slate-950 border-slate-800 text-indigo-550 focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5 cursor-pointer"
                  />
                  <label htmlFor="hide-low-pts-side" className="text-[9px] text-slate-500 font-bold select-none cursor-pointer">
                    Ẩn ít điểm
                  </label>
                </div>
              </div>

              {/* Mini account list */}
              <div className="space-y-1.5 max-h-[300px] overflow-y-auto pr-1">
                {(() => {
                  const visibleList = accountsList.filter(a => {
                    if (hideLowPoints) {
                      return a.points >= getLowPointsThreshold(selectedProvider) && a.status !== 'LOW_CREDIT';
                    }
                    return true;
                  });

                  if (visibleList.length === 0) {
                    return (
                      <p className="text-[10px] text-slate-500 italic text-center py-4 border border-dashed border-slate-800 rounded-xl">
                        Không có tài khoản nào.
                      </p>
                    );
                  }

                  return visibleList.map(acc => {
                    const activeEmail = selectedProvider.toUpperCase() === 'DREAMINA' ? activeDreaminaEmail : (activeEmails[selectedProvider.toUpperCase()] || "");
                    const isActive = activeEmail.toLowerCase() === acc.email.toLowerCase();
                    const isLow = acc.points < getLowPointsThreshold(selectedProvider);
                    
                    return (
                      <div 
                        key={acc.email}
                        className={`flex items-center justify-between p-2 rounded-lg border text-[10px] transition-all ${
                          isActive 
                            ? 'bg-indigo-955/20 border-indigo-500/50' 
                            : 'bg-slate-950/30 border-slate-900 hover:border-slate-850'
                        }`}
                      >
                        <div className="min-w-0 space-y-0.5 flex-1 pr-2">
                          <p className={`font-semibold truncate ${isActive ? 'text-indigo-405' : 'text-slate-355'}`}>
                            {acc.email}
                          </p>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={`text-[8px] font-extrabold px-1 rounded ${
                              isLow ? 'bg-rose-955/50 text-rose-400' : 'bg-emerald-955/50 text-emerald-400'
                            }`}>
                              {acc.points} P
                            </span>
                            {isActive && <span className="text-[8px] font-bold text-emerald-400 bg-emerald-955/40 px-1 rounded border border-emerald-900/30">Active</span>}
                          </div>
                        </div>

                        <div className="shrink-0">
                          {isActive ? (
                            <button
                              onClick={() => handleReleaseAccount(selectedProvider, acc.email)}
                              className="bg-slate-800 hover:bg-slate-705 text-[8px] font-extrabold px-1.5 py-0.5 rounded text-slate-300"
                            >
                              Release
                            </button>
                          ) : (
                            <button
                              onClick={() => handleSwitchAccount(selectedProvider, acc.email, acc.cookieStr)}
                              disabled={verifyingEmail !== null}
                              className="bg-indigo-650 hover:bg-indigo-600 disabled:opacity-50 text-[8px] font-extrabold px-2 py-0.5 rounded text-white"
                            >
                              {verifyingEmail === acc.email ? '...' : 'Switch'}
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  });
                })()}
              </div>
            </div>
          )}
        </main>
      </div>
    );
  }

  // 2. FULL SCREEN GIAO DIỆN HOÀNH TRÁNG (2 CỘT)
  return (
    <div className="min-h-screen bg-slate-955 text-slate-100 flex font-sans relative overflow-hidden">
      {/* Background neon glows */}
      <div className="absolute top-[-10%] left-[-25%] w-[50%] h-[50%] bg-purple-955/15 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-25%] w-[50%] h-[50%] bg-indigo-955/15 rounded-full blur-[140px] pointer-events-none" />

      {/* ========================================================== */}
      {/* CỘT TRÁI - SIDEBAR 320PX */}
      {/* ========================================================== */}
      <aside className="w-[320px] bg-slate-900/30 border-r border-slate-800/60 flex flex-col justify-between shrink-0 p-4 space-y-4 overflow-y-auto max-h-screen backdrop-blur-xl z-20">
        <div className="space-y-4">
          {/* Logo & WS Connection Status */}
          <div className="flex items-center gap-3 pb-3 border-b border-slate-800/50">
            <div className="p-2 bg-gradient-to-tr from-purple-600 to-indigo-600 rounded-xl shadow-lg shadow-indigo-550/20">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="text-sm font-bold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                Universal AI Director
              </h1>
              <p className="text-[10px] text-slate-500">StoryMee Automated Worker v1.0</p>
            </div>
          </div>

          {/* WS Status Badge & Reconnect Button */}
          <div className="bg-slate-950/60 border border-slate-850 p-3 rounded-xl flex items-center justify-between">
            <div className="flex flex-col gap-0.5">
              <span className="text-[9px] uppercase tracking-wider text-slate-500 font-bold">WS Status</span>
              <div className="flex items-center gap-1.5">
                <span className={`inline-flex items-center gap-1 text-[11px] font-bold ${
                  workerState === 'ONLINE' ? 'text-emerald-400' : workerState === 'CONNECTING' ? 'text-amber-400' : 'text-rose-405'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    workerState === 'ONLINE' ? 'bg-emerald-400 animate-pulse' : workerState === 'CONNECTING' ? 'bg-amber-400 animate-bounce' : 'bg-rose-500'
                  }`} />
                  {workerState}
                </span>
                {getRouteBadge()}
              </div>
            </div>
            <button 
              onClick={handleConnectWs}
              className="bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-[10px] font-extrabold px-3 py-1.5 rounded-lg transition-all shadow-md shadow-indigo-600/10 flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              Reconnect
            </button>
          </div>

          {/* Google Identity Captured Badge */}
          {googleEmail && (
            <div className="flex items-center gap-2 bg-slate-950/40 p-2.5 rounded-xl border border-slate-850/60 animate-fadeIn">
              {googleAvatar ? (
                <img src={googleAvatar} alt="Google" className="w-6 h-6 rounded-full border border-purple-500/20" />
              ) : (
                <User className="w-4 h-4 text-slate-550" />
              )}
              <div className="min-w-0 flex-1">
                <p className="text-[8px] uppercase tracking-wider text-slate-500 font-bold">Google Identity</p>
                <p className="text-[10px] text-slate-400 truncate">{googleEmail}</p>
              </div>
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            </div>
          )}

          {/* Worker Name Config */}
          <section className="bg-slate-955/30 border border-slate-855/60 rounded-xl p-3 space-y-2">
            <h2 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Cpu className="w-3 h-3 text-purple-400" />
              Tên Worker Này
            </h2>
            <div className="flex gap-2">
              <input
                type="text"
                value={workerName}
                onChange={(e) => setWorkerName(e.target.value)}
                placeholder="Studio-PC, Worker-1..."
                className="flex-1 bg-slate-950 border border-slate-800 focus:border-violet-500 focus:ring-1 focus:ring-violet-500 text-xs rounded-lg px-2.5 py-1.5 text-slate-200 outline-none placeholder-slate-650"
              />
              <button
                onClick={async () => {
                  if (workerName.trim() && typeof chrome !== 'undefined' && chrome.storage) {
                    await chrome.storage.local.set({ workerName: workerName.trim() });
                    chrome.runtime.sendMessage({ type: "FORCE_RECONNECT_WS" }).catch(() => {});
                    alert("Đã lưu tên worker và khởi động lại WebSocket!");
                  }
                }}
                className="bg-violet-650 hover:bg-violet-500 active:scale-95 text-white font-bold text-[10px] px-3 rounded-lg transition-all"
              >
                Lưu
              </button>
            </div>
          </section>

          {/* Gateway Connection Config */}
          <section className="bg-slate-955/30 border border-slate-855/60 rounded-xl p-3 space-y-2">
            <h2 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Settings className="w-3 h-3 text-indigo-400" />
              Gateway Connection (Hub URL)
            </h2>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={gflowUrl} 
                onChange={(e) => setGflowUrl(e.target.value)} 
                placeholder="https://hub.storymee.com" 
                className="flex-1 bg-slate-950 border border-slate-800 focus:border-indigo-505 focus:ring-1 focus:ring-indigo-550 text-xs rounded-lg px-2.5 py-1.5 text-slate-202 outline-none"
              />
              <button
                onClick={async () => {
                  if (gflowUrl.trim() && typeof chrome !== 'undefined' && chrome.storage) {
                    await chrome.storage.local.set({ gflowUrl: gflowUrl.trim() });
                    chrome.runtime.sendMessage({ action: "CONNECT_WS", payload: { gflowUrl: gflowUrl.trim() } });
                    alert("Đã lưu Gateway URL và kết nối lại!");
                  }
                }}
                className="bg-indigo-650 hover:bg-indigo-600 active:scale-95 text-white font-bold text-[10px] px-3 rounded-lg transition-all"
              >
                Lưu
              </button>
            </div>
            <div className="grid grid-cols-2 gap-1.5 pt-1.5">
              <button
                onClick={() => {
                  setGflowUrl("https://local-hub.storymee.com");
                  if (typeof chrome !== 'undefined' && chrome.storage) {
                    chrome.storage.local.set({ gflowUrl: "https://local-hub.storymee.com" }).then(() => {
                      chrome.runtime.sendMessage({ action: "CONNECT_WS", payload: { gflowUrl: "https://local-hub.storymee.com" } });
                    });
                  }
                }}
                className="bg-slate-955 hover:bg-slate-900 border border-slate-800 text-[9px] text-indigo-404 py-1 rounded font-bold transition-all text-center"
              >
                Local (5100)
              </button>
              <button
                onClick={() => {
                  setGflowUrl("http://173.249.19.167:5100");
                  if (typeof chrome !== 'undefined' && chrome.storage) {
                    chrome.storage.local.set({ gflowUrl: "http://173.249.19.167:5100" }).then(() => {
                      chrome.runtime.sendMessage({ action: "CONNECT_WS", payload: { gflowUrl: "http://173.249.19.167:5100" } });
                    });
                  }
                }}
                className="bg-slate-955 hover:bg-slate-900 border border-slate-800 text-[9px] text-amber-500 py-1 rounded font-bold transition-all text-center"
              >
                VPS
              </button>
            </div>
          </section>

          {/* Engine & Auto Switch settings */}
          <div className="bg-slate-950/30 border border-slate-850/60 rounded-xl p-3 space-y-2.5 text-[10px] animate-fadeIn">
            <div className="flex items-center justify-between">
              <span className="text-slate-400 font-semibold">Tự động xoay tài khoản (Auto-Switch):</span>
              <button
                onClick={() => handleToggleAutoSwitch(!autoSwitchEnabled)}
                className={`w-7 h-4 rounded-full transition-all relative ${autoSwitchEnabled ? 'bg-indigo-650' : 'bg-slate-800'}`}
              >
                <span className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all ${autoSwitchEnabled ? 'right-0.5' : 'left-0.5'}`} />
              </button>
            </div>
            {selectedProvider === 'DREAMINA' && (
              <div className="flex items-center justify-between border-t border-slate-850/50 pt-2">
                <span className="text-slate-400 font-semibold">Engine Dreamina:</span>
                <div className="flex bg-slate-900 p-0.5 border border-slate-800 rounded">
                  <button
                    onClick={() => handleToggleExecutionMode('extension')}
                    className={`px-1.5 py-0.5 rounded text-[8px] font-bold ${dreaminaExecutionMode === 'extension' ? 'bg-pink-600 text-white' : 'text-slate-500 hover:text-slate-300'}`}
                  >
                    Ext
                  </button>
                  <button
                    onClick={() => handleToggleExecutionMode('headless')}
                    className={`px-1.5 py-0.5 rounded text-[8px] font-bold ${dreaminaExecutionMode === 'headless' ? 'bg-indigo-650 text-white' : 'text-slate-500 hover:text-slate-300'}`}
                  >
                    Headless
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Active Executor Block */}
          {activeExecutor && (
            <div className="bg-slate-950/40 border border-slate-855/65 p-3 rounded-xl space-y-1 animate-fadeIn">
              <div className="flex items-center gap-1.5 text-[9px] font-bold text-slate-450 uppercase tracking-wider">
                <Activity className="w-3 h-3 text-pink-400 shrink-0" />
                Active Executor
              </div>
              <p className="text-[10px] text-slate-300 truncate font-mono">{activeExecutor.email}</p>
              <p className="text-[8px] text-slate-500">Provider: {activeExecutor.provider} | Status: {activeExecutor.status} | {activeExecutor.points} Pts</p>
            </div>
          )}

          {/* Hub API & Decryption Key */}
          <section className="bg-slate-955/30 border border-slate-855/60 rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-emerald-400" />
                Hub Decryption key ({selectedProvider})
              </h2>
            </div>
            <div className="relative">
              <input
                type={showApiKey ? "text" : "password"}
                value={hubApiKey}
                onChange={(e) => setHubApiKey(e.target.value)}
                placeholder="sk-storymee-..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-xs font-mono rounded-lg pl-2.5 pr-8 py-1.5 text-slate-300 outline-none"
              />
              <button
                type="button"
                onClick={() => setShowApiKey(!showApiKey)}
                className="absolute right-2.5 top-1.5 text-slate-505 hover:text-slate-300 text-[10px] font-bold"
              >
                {showApiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
            <button
              onClick={handleSaveHubApiKey}
              className="w-full bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold text-[10px] py-1.5 rounded-lg transition-all"
            >
              Lưu & Đồng bộ Accounts
            </button>
          </section>

          {/* Session Vault Headers Accordion */}
          <section className="bg-slate-955/30 border border-slate-855/60 rounded-xl overflow-hidden">
            <button
              onClick={() => setShowVaultHeaders(!showVaultHeaders)}
              className="w-full px-3 py-2.5 flex items-center justify-between text-left hover:bg-slate-900/40 transition-all"
            >
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-pink-400" />
                Session Vault Headers
              </span>
              {showVaultHeaders ? <ChevronUp className="w-3.5 h-3.5 text-slate-500" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-500" />}
            </button>
            
            {showVaultHeaders && (
              <div className="p-3 border-t border-slate-800/50 space-y-2 text-[10px]">
                <div>
                  <label className="text-[8px] font-semibold text-slate-500 block mb-0.5">Google OAuth ya29 Token</label>
                  <div className="flex gap-1.5">
                    <input 
                      type="password" 
                      readOnly 
                      value={oauthToken || "No Google token captured"} 
                      className="flex-1 bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-400 outline-none font-mono text-[9px]"
                    />
                    <button 
                      onClick={() => copyToClipboard(oauthToken)}
                      className="bg-slate-850 hover:bg-slate-750 px-2 rounded border border-slate-700 text-slate-305"
                    >
                      Copy
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-[8px] font-semibold text-slate-500 block mb-0.5">x-browser-validation</label>
                  <div className="flex gap-1.5">
                    <input 
                      type="password" 
                      readOnly 
                      value={xBrowserValidation || "No validation signature"} 
                      className="flex-1 bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-400 outline-none font-mono text-[9px]"
                    />
                    <button 
                      onClick={() => copyToClipboard(xBrowserValidation)}
                      className="bg-slate-850 hover:bg-slate-750 px-2 rounded border border-slate-700 text-slate-305"
                    >
                      Copy
                    </button>
                  </div>
                </div>
                <div>
                  <label className="text-[8px] font-semibold text-slate-500 block mb-0.5">x-client-data</label>
                  <div className="flex gap-1.5">
                    <input 
                      type="password" 
                      readOnly 
                      value={xClientData || "No client data signature"} 
                      className="flex-1 bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-400 outline-none font-mono text-[9px]"
                    />
                    <button 
                      onClick={() => copyToClipboard(xClientData)}
                      className="bg-slate-850 hover:bg-slate-750 px-2 rounded border border-slate-700 text-slate-305"
                    >
                      Copy
                    </button>
                  </div>
                </div>
              </div>
            )}
          </section>

          {/* Rotation History Log */}
          <section className="bg-slate-955/30 border border-slate-855/60 rounded-xl p-3 space-y-2">
            <h2 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <RefreshCw className="w-3 h-3 text-amber-400" />
              Rotation History Log
            </h2>
            {rotationLog && rotationLog.length > 0 ? (
              <div className="max-h-[140px] overflow-y-auto space-y-1.5 pr-1 text-[9px]">
                {rotationLog.map((log: any, idx: number) => (
                  <div key={idx} className="bg-slate-950/60 rounded-lg p-2 border border-slate-900">
                    <div className="flex justify-between items-center text-slate-500 font-semibold mb-1">
                      <span>Job: ...{log.taskId?.slice(-6)}</span>
                      <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <div className="flex items-center gap-1 text-slate-305">
                      <span className="text-rose-400 truncate max-w-[80px]">{log.fromEmail || "NULL"}</span>
                      <span>➔</span>
                      <span className="text-emerald-400 truncate max-w-[80px]">{log.toEmail || "ROTATE"}</span>
                    </div>
                    <p className="text-[8px] text-slate-500 italic mt-0.5 truncate">{log.reason}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-[10px] text-slate-500 italic text-center py-2">
                Chưa có sự kiện xoay vòng nào
              </div>
            )}
          </section>
        </div>

        {/* Developer Credit Footer */}
        <div className="pt-3 border-t border-slate-800/40 text-center text-[9px] text-slate-600">
          Designed by Worker-agent &copy; 2026 StoryMee
        </div>
      </aside>

      {/* ========================================================== */}
      {/* CỘT PHẢI - NỘI DUNG CHÍNH */}
      {/* ========================================================== */}
      <main className="flex-1 flex flex-col overflow-y-auto max-h-screen p-6 space-y-6 z-10">
        
        {/* Main Header / Switcher */}
        <header className="flex items-center justify-between pb-4 border-b border-slate-800/50">
          <div className="flex bg-slate-900/60 p-1.5 border border-slate-850 rounded-xl gap-1">
            <button 
              onClick={() => setActiveTab('accounts')}
              className={`px-5 py-2 text-xs font-bold uppercase rounded-lg transition-all ${
                activeTab === 'accounts' 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Kho Tài Khoản
            </button>
            <button 
              onClick={() => setActiveTab('dashboard')}
              className={`px-5 py-2 text-xs font-bold uppercase rounded-lg transition-all ${
                activeTab === 'dashboard' 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Lịch sử Jobs
            </button>
          </div>

          {activeTab === 'accounts' ? (
            <div className="flex items-center gap-3 animate-fadeIn">
              <div className="flex items-center gap-1.5 bg-slate-900 p-2 rounded-lg border border-slate-800 shadow-sm">
                <input
                  type="checkbox"
                  id="hide-low-pts"
                  checked={hideLowPoints}
                  onChange={(e) => {
                    setHideLowPoints(e.target.checked);
                    chrome.storage.local.set({ hide_low_points: e.target.checked });
                  }}
                  className="rounded bg-slate-950 border-slate-800 text-indigo-500 focus:ring-0 focus:ring-offset-0 w-3.5 h-3.5 cursor-pointer"
                />
                <label htmlFor="hide-low-pts" className="text-[9px] text-slate-500 font-bold select-none cursor-pointer">
                  Ẩn ít điểm
                </label>
              </div>
              
              <button
                onClick={handleRequestMoreAccounts}
                className="bg-indigo-950/40 hover:bg-indigo-900/60 text-indigo-400 border border-indigo-500/20 text-[10px] font-bold px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-all"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Xin thêm Account
              </button>
              <button
                onClick={syncAllAccounts}
                disabled={isSyncingAccounts}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 disabled:opacity-50 text-slate-205 text-xs font-bold px-4 py-2 rounded-xl transition-all flex items-center gap-2 active:scale-95 shadow-sm"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncingAccounts ? 'animate-spin' : ''}`} />
                Đồng bộ tất cả tài khoản
              </button>
            </div>
          ) : (
            <button
              onClick={syncAllAccounts}
              disabled={isSyncingAccounts}
              className="bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 disabled:opacity-50 text-slate-205 text-xs font-bold px-4 py-2 rounded-xl transition-all flex items-center gap-2 active:scale-95 shadow-sm"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncingAccounts ? 'animate-spin' : ''}`} />
              Đồng bộ tất cả tài khoản
            </button>
          )}
        </header>

        {/* -------------------------------------------------------- */}
        {/* TAB 1: QUẢN LÝ JOBS */}
        {/* -------------------------------------------------------- */}
        {activeTab === 'dashboard' && (
          <section className="space-y-6 animate-fadeIn">
            {/* Statistics */}
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-slate-900/40 border border-slate-850 rounded-2xl p-4 flex flex-col justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Tổng Jobs nhận</span>
                <span className="text-3xl font-black text-slate-100 mt-2">{totalJobsCount}</span>
              </div>
              <div className="bg-amber-955/20 border border-amber-500/20 rounded-2xl p-4 flex flex-col justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">Đang xử lý</span>
                <span className="text-3xl font-black text-amber-400 mt-2 animate-pulse">{processingJobsCount}</span>
              </div>
              <div className="bg-emerald-955/20 border border-emerald-500/20 rounded-2xl p-4 flex flex-col justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">Hoàn thành</span>
                <span className="text-3xl font-black text-emerald-400 mt-2">{doneJobsCount}</span>
              </div>
              <div className="bg-rose-955/20 border border-rose-500/20 rounded-2xl p-4 flex flex-col justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-rose-455">Thất bại</span>
                <span className="text-3xl font-black text-rose-455 mt-2">{failedJobsCount}</span>
              </div>
            </div>

            {/* Filter & Search Bar */}
            <div className="bg-slate-900/40 border border-slate-850 rounded-2xl p-4 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap gap-3">
                  {/* Status Filter */}
                  <div className="flex bg-slate-950 p-1 border border-slate-800 rounded-xl gap-1">
                    {(['all', 'processing', 'done', 'failed'] as const).map(status => {
                      const isActive = jobStatusFilter === status;
                      return (
                        <button
                          key={status}
                          onClick={() => setJobStatusFilter(status)}
                          className={`px-3 py-1.5 text-xs font-bold uppercase rounded-lg transition-all ${
                            isActive 
                              ? 'bg-slate-800 text-indigo-400 border border-slate-700' 
                              : 'text-slate-400 hover:text-slate-200 border border-transparent'
                          }`}
                        >
                          {status === 'all' ? 'Tất cả' : status === 'processing' ? 'Đang chạy' : status === 'done' ? 'Xong' : 'Lỗi'}
                        </button>
                      );
                    })}
                  </div>

                  {/* Provider Filter */}
                  <div className="flex bg-slate-950 p-1 border border-slate-800 rounded-xl gap-1">
                    {(['ALL', 'DREAMINA', 'PICSART', 'TOPVIEW', 'GFLOW'] as const).map(prov => {
                      const isActive = jobProviderFilter === prov;
                      return (
                        <button
                          key={prov}
                          onClick={() => setJobProviderFilter(prov)}
                          className={`px-3 py-1.5 text-xs font-bold uppercase rounded-lg transition-all ${
                            isActive 
                              ? 'bg-indigo-650 text-white border border-indigo-500/20' 
                              : 'text-slate-400 hover:text-slate-200 border border-transparent'
                          }`}
                        >
                          {prov === 'ALL' ? 'Tất cả nguồn' : prov === 'GFLOW' ? 'Google Flow' : prov.charAt(0) + prov.slice(1).toLowerCase()}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center gap-3 flex-1 max-w-md">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      value={jobSearchQuery}
                      onChange={(e) => setJobSearchQuery(e.target.value)}
                      placeholder="Tìm theo Prompt, Email, ID..."
                      className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-xs rounded-xl pl-10 pr-3 py-2.5 text-slate-200 placeholder-slate-600 outline-none"
                    />
                  </div>

                  <button
                    onClick={fetchJobsFromHub}
                    disabled={isFetchingJobs}
                    className="p-2.5 bg-slate-955 hover:bg-slate-900 border border-slate-800 rounded-xl text-slate-400 hover:text-slate-202 transition-all disabled:opacity-50"
                    title="Làm mới lịch sử tác vụ"
                  >
                    <RefreshCw className={`w-4 h-4 ${isFetchingJobs ? 'animate-spin text-indigo-400' : ''}`} />
                  </button>
                </div>
              </div>
            </div>

            {/* Jobs list grid layout */}
            {failedHosts.length > 0 && (
              <div className="space-y-2 mb-4">
                {failedHosts.map(host => (
                  <div key={host} className="bg-amber-955/20 border border-amber-500/20 rounded-xl p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-400">
                    <div className="flex items-start gap-2.5 text-xs leading-relaxed">
                      <AlertCircle className="w-5 h-5 text-amber-500 flex-shrink-0 animate-pulse mt-0.5" />
                      <div>
                        <p className="font-bold text-[12px]">Lỗi chứng chỉ bảo mật SSL ({host})</p>
                        <p className="text-[10px] text-slate-400 mt-0.5">
                          Trình duyệt chặn tải ảnh/video từ host lưu trữ này do chứng chỉ chưa được tin cậy. 
                          Sếp vui lòng click <strong>Bypass SSL</strong> &rarr; chọn <strong>Nâng cao (Advanced)</strong> &rarr; <strong>Tiếp tục truy cập (Proceed to... unsafe)</strong>. Sau đó quay lại đây bấm làm mới lịch sử để tải ảnh!
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => window.open(`https://${host}/`, '_blank')}
                      className="bg-amber-600 hover:bg-amber-500 text-white font-bold text-[10px] px-3 py-1.5 rounded-lg flex items-center gap-1 transition-all whitespace-nowrap self-stretch sm:self-auto justify-center"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Bypass SSL
                    </button>
                  </div>
                ))}
              </div>
            )}

            {filteredJobs.length === 0 ? (
              <div className="bg-slate-900/20 border border-slate-900 border-dashed rounded-2xl py-12 text-center text-slate-500">
                <ImageIcon className="w-12 h-12 text-slate-700 mx-auto mb-3" />
                <p className="text-sm font-medium">Không tìm thấy jobs nào phù hợp.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredJobs.map(job => (
                  <JobCard 
                    key={job.id} 
                    job={job} 
                    copyToClipboard={copyToClipboard} 
                    onViewDetails={setSelectedJobForModal}
                    onSwitchAccount={onSwitchAccountFromJob}
                    onMediaError={(url) => {
                      try {
                        const parsed = new URL(url);
                        const host = parsed.host.toLowerCase();
                        if (parsed.protocol === 'https:' && (
                          host.includes('storymee.com') ||
                          host.includes('localhost') ||
                          host.includes('127.0.0.1') ||
                          host.startsWith('192.168.') ||
                          host.startsWith('10.')
                        )) {
                          setFailedHosts(prev => {
                            if (!prev.includes(parsed.host)) {
                              return [...prev, parsed.host];
                            }
                            return prev;
                          });
                        }
                      } catch {}
                    }}
                  />
                ))}
              </div>
            )}
          </section>
        )}

        {/* -------------------------------------------------------- */}
        {/* TAB 2: KHO TÀI KHOẢN (GRID 4 CỘT) */}
        {/* -------------------------------------------------------- */}
        {activeTab === 'accounts' && (
          <section className="grid grid-cols-1 xl:grid-cols-4 gap-6 animate-fadeIn">
            {/* Cột 1: DREAMINA */}
            <div className="bg-slate-900/40 border border-slate-850 rounded-2xl p-4 flex flex-col justify-between gap-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
                  <h3 className="text-xs font-black uppercase text-pink-400 tracking-wider flex items-center gap-2">
                    <Layers className="w-4 h-4 text-pink-400" />
                    Dreamina
                  </h3>
                  <span className="text-[10px] bg-slate-950 border border-slate-800 px-2 py-0.5 rounded-full text-slate-400 font-bold">
                    {dreaminaAccounts.length} Accs
                  </span>
                </div>
                {renderProviderAccountsColumn(dreaminaAccounts, 'DREAMINA')}
              </div>
            </div>

            {/* Cột 2: PICSART */}
            <div className="bg-slate-900/40 border border-slate-850 rounded-2xl p-4 flex flex-col justify-between gap-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
                  <h3 className="text-xs font-black uppercase text-violet-400 tracking-wider flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-violet-400" />
                    Picsart Gold
                  </h3>
                  <span className="text-[10px] bg-slate-950 border border-slate-800 px-2 py-0.5 rounded-full text-slate-400 font-bold">
                    {picsartAccounts.length} Accs
                  </span>
                </div>
                {renderProviderAccountsColumn(picsartAccounts, 'PICSART')}
              </div>
            </div>

            {/* Cột 3: TOPVIEW */}
            <div className="bg-slate-900/40 border border-slate-850 rounded-2xl p-4 flex flex-col justify-between gap-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
                  <h3 className="text-xs font-black uppercase text-emerald-400 tracking-wider flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-emerald-400" />
                    TopView Pro
                  </h3>
                  <span className="text-[10px] bg-slate-950 border border-slate-800 px-2 py-0.5 rounded-full text-slate-400 font-bold">
                    {topviewAccounts.length} Accs
                  </span>
                </div>
                {renderProviderAccountsColumn(topviewAccounts, 'TOPVIEW')}
              </div>
            </div>

            {/* Cột 4: GFLOW */}
            <div className="bg-slate-900/40 border border-slate-850 rounded-2xl p-4 flex flex-col justify-between gap-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
                  <h3 className="text-xs font-black uppercase text-purple-400 tracking-wider flex items-center gap-2">
                    <Globe className="w-4 h-4 text-purple-400" />
                    Google Flow
                  </h3>
                  <span className="text-[10px] bg-slate-950 border border-slate-800 px-2 py-0.5 rounded-full text-slate-400 font-bold">
                    {gflowAccounts.length} Accs
                  </span>
                </div>
                {renderProviderAccountsColumn(gflowAccounts, 'GFLOW')}
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Details Modal */}
      {selectedJobForModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-4 transition-all duration-300">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden shadow-2xl relative animate-fadeIn">
            {/* Header */}
            <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500 font-mono">Job Details:</span>
                <span className="text-xs font-mono text-indigo-400 font-bold bg-indigo-955/40 border border-indigo-500/20 px-2 py-0.5 rounded select-all">
                  {selectedJobForModal.id}
                </span>
              </div>
              <button 
                onClick={() => setSelectedJobForModal(null)}
                className="text-slate-450 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto space-y-5">
              {/* Media Preview if done */}
              {selectedJobForModal.status === 'done' && selectedJobForModal.resultUrl && (
                <div className="bg-black/60 rounded-xl border border-slate-800 p-3 flex flex-col items-center justify-center max-h-[280px] overflow-hidden relative">
                  {selectedJobForModal.mediaType === 'video' ? (
                    <video 
                      src={selectedJobForModal.resultUrl} 
                      className="max-h-[200px] max-w-full rounded-lg object-contain" 
                      controls 
                      autoPlay
                      muted
                      playsInline
                    />
                  ) : selectedJobForModal.mediaType === 'image' && !selectedJobForModal.resultUrl.startsWith('{') && !selectedJobForModal.resultUrl.startsWith('[') ? (
                    <img 
                      src={selectedJobForModal.resultUrl} 
                      alt="Full Preview" 
                      className="max-h-[200px] max-w-full rounded-lg object-contain"
                    />
                  ) : (
                    <div className="text-xs font-mono text-slate-400 p-4 break-all max-w-full overflow-x-auto max-h-[200px]">
                      {selectedJobForModal.resultUrl}
                    </div>
                  )}
                  
                  {/* Floating Action Strip */}
                  <div className="flex gap-2 mt-3">
                    <button
                      onClick={() => {
                        copyToClipboard(selectedJobForModal.resultUrl!);
                        alert("Đã copy link kết quả!");
                      }}
                      className="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] font-bold px-3 py-1.5 rounded-lg text-slate-300 hover:text-white flex items-center gap-1.5 transition-all shadow-md"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Copy Link Kết Quả
                    </button>
                    {!selectedJobForModal.resultUrl.startsWith('{') && !selectedJobForModal.resultUrl.startsWith('[') && (
                      <a 
                        href={selectedJobForModal.resultUrl} 
                        target="_blank" 
                        rel="noreferrer"
                        className="bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all shadow-md"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        Xem gốc
                      </a>
                    )}
                  </div>
                </div>
              )}

              {/* Prompt Box */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Prompt</span>
                  <button
                    onClick={() => {
                      copyToClipboard(selectedJobForModal.prompt);
                      alert("Đã copy Prompt!");
                    }}
                    className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" /> Copy Prompt
                  </button>
                </div>
                <div className="bg-slate-950 border border-slate-855 p-4 rounded-xl text-sm italic font-semibold text-slate-200 leading-relaxed max-h-[140px] overflow-y-auto break-words select-all">
                  "{selectedJobForModal.prompt}"
                </div>
              </div>

              {/* Error Message if failed */}
              {selectedJobForModal.error && (
                <div className="bg-rose-955/15 border border-rose-500/20 p-4 rounded-xl text-xs text-rose-400 leading-relaxed">
                  <strong className="block text-[10px] uppercase tracking-wider text-rose-500 font-bold mb-1">ErrorMessage</strong>
                  {selectedJobForModal.error}
                </div>
              )}

              {/* Metadata Grid */}
              <div className="bg-slate-950/40 border border-slate-850 rounded-xl p-4">
                <h4 className="text-[10px] uppercase font-bold tracking-wider text-slate-500 mb-3 pb-1 border-b border-slate-800/60">Thông số kĩ thuật & Metadata</h4>
                <div className="grid grid-cols-2 gap-y-3 gap-x-6 text-xs">
                  <div className="flex flex-col gap-0.5">
                    <span className="text-slate-500 text-[10px]">Nhà cung cấp:</span>
                    <span className="font-semibold text-slate-200 uppercase">{selectedJobForModal.provider}</span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-slate-500 text-[10px]">Trạng thái:</span>
                    <span className={`font-bold capitalize ${
                      selectedJobForModal.status === 'done' ? 'text-emerald-450' :
                      selectedJobForModal.status === 'failed' ? 'text-rose-455' : 'text-amber-400 animate-pulse'
                    }`}>{selectedJobForModal.status}</span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-slate-500 text-[10px]">Phân loại:</span>
                    <span className="font-semibold text-slate-200 capitalize">{selectedJobForModal.mediaType}</span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-slate-500 text-[10px]">Hàng đợi (Pool):</span>
                    <span className="font-semibold text-slate-200">{selectedJobForModal.pool === 'partner' ? '🤝 Partner' : '🏠 Internal'}</span>
                  </div>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-slate-500 text-[10px]">Nguồn (Source):</span>
                    <span className="font-semibold text-slate-200">{selectedJobForModal.source === 'web' ? '🌐 Web Direct' : '🔌 Hub API'}</span>
                  </div>
                  {selectedJobForModal.batchName && (
                    <div className="flex flex-col gap-0.5 col-span-2">
                      <span className="text-slate-500 text-[10px]">Chiến dịch / Batch Name:</span>
                      <span className="font-semibold text-slate-200">{selectedJobForModal.batchName}</span>
                    </div>
                  )}
                  {selectedJobForModal.modelDisp && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-slate-500 text-[10px]">Model:</span>
                      <span className="font-mono text-slate-200">{selectedJobForModal.modelDisp}</span>
                    </div>
                  )}
                  {selectedJobForModal.ratioDisp && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-slate-500 text-[10px]">Tỉ lệ (Ratio):</span>
                      <span className="font-mono text-slate-200">{selectedJobForModal.ratioDisp}</span>
                    </div>
                  )}
                  {selectedJobForModal.durationDisp && selectedJobForModal.durationDisp !== '—' && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-slate-500 text-[10px]">Thời lượng:</span>
                      <span className="font-mono text-slate-200">{selectedJobForModal.durationDisp}</span>
                    </div>
                  )}
                  <div className="flex flex-col gap-0.5">
                    <span className="text-slate-500 text-[10px]">Thời gian nhận:</span>
                    <span className="font-semibold text-slate-200">
                      {new Date(selectedJobForModal.timestamp).toLocaleString()}
                    </span>
                  </div>
                  {selectedJobForModal.executedBy && (
                    <div className="flex flex-col gap-0.5 col-span-2">
                      <span className="text-slate-500 text-[10px]">Thực thi bởi (Worker Email):</span>
                      <span className="font-semibold text-slate-300 font-mono select-all">{selectedJobForModal.executedBy}</span>
                    </div>
                  )}
                  {selectedJobForModal.projectName && (
                    <div className="flex flex-col gap-0.5 col-span-2">
                      <span className="text-slate-500 text-[10px]">Dự án (Project):</span>
                      {selectedJobForModal.projectLink ? (
                        <a href={selectedJobForModal.projectLink} target="_blank" rel="noreferrer" className="text-indigo-405 hover:text-indigo-300 font-semibold underline flex items-center gap-1">
                          {selectedJobForModal.projectName}
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      ) : (
                        <span className="font-semibold text-slate-200">{selectedJobForModal.projectName}</span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="px-5 py-4 border-t border-slate-800 flex justify-end gap-2 bg-slate-900/60">
              <button 
                onClick={() => setSelectedJobForModal(null)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-bold px-4 py-2 rounded-xl transition-all"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // Helper render accounts column for Kho Tài Khoản
  function renderProviderAccountsColumn(accounts: any[], provider: string) {
    const threshold = getLowPointsThreshold(provider);
    const visibleAccounts = accounts.filter(a => {
      if (hideLowPoints) {
        return a.points >= threshold && a.status !== 'LOW_CREDIT';
      }
      return true;
    });

    if (visibleAccounts.length === 0) {
      return (
        <div className="text-center py-8 border border-dashed border-slate-800 rounded-xl space-y-2">
          <AlertCircle className="w-5 h-5 text-slate-650 mx-auto" />
          <p className="text-[10px] text-slate-500">Không có tài khoản nào.</p>
        </div>
      );
    }

    return (
      <div className="space-y-2 max-h-[560px] overflow-y-auto pr-1">
        {visibleAccounts.map(acc => {
          const activeEmail = provider.toUpperCase() === 'DREAMINA' ? activeDreaminaEmail : (activeEmails[provider.toUpperCase()] || "");
          const isActive = activeEmail.toLowerCase() === acc.email.toLowerCase();
          const isLow = acc.points < threshold || acc.points <= 0 || acc.status === 'LOW_CREDIT';
          
          return (
            <div 
              key={acc.email}
              className={`p-3 rounded-xl border flex flex-col justify-between gap-2.5 transition-all ${
                isActive 
                  ? 'bg-indigo-955/15 border-indigo-500/50 shadow-md shadow-indigo-500/5' 
                  : 'bg-slate-950/40 border-slate-900 hover:border-slate-850'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 min-w-0 flex-1">
                    <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${isActive ? 'bg-indigo-400 animate-pulse' : 'bg-slate-600'}`} />
                    <p className={`text-xs font-bold truncate ${isActive ? 'text-indigo-405' : 'text-slate-355'}`} title={acc.email}>
                      {acc.email}
                    </p>
                  </div>
                  <span className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded shrink-0 ${
                    isLow ? 'bg-rose-955/50 border border-rose-500/20 text-rose-455' : 'bg-emerald-955/50 border border-emerald-500/20 text-emerald-450'
                  }`}>
                    {acc.points} P
                  </span>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {getAccountTierBadge(acc, provider)}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800/40">
                <span className="text-[9px] text-slate-500 font-medium">
                  {acc.lastChecked ? `Checked: ${new Date(acc.lastChecked).toLocaleTimeString()}` : 'Chưa verify'}
                </span>
                
                <div className="flex gap-1.5">
                  {isActive ? (
                    <button
                      onClick={() => handleReleaseAccount(provider, acc.email)}
                      className="bg-slate-850 hover:bg-slate-755 text-slate-300 text-[9px] font-extrabold px-2 py-0.5 rounded transition-all active:scale-95"
                    >
                      Release
                    </button>
                  ) : (
                    <button
                      onClick={() => handleSwitchAccount(provider, acc.email, acc.cookieStr)}
                      disabled={verifyingEmail !== null}
                      className="bg-indigo-650 hover:bg-indigo-600 disabled:opacity-50 text-white text-[9px] font-extrabold px-2 py-0.5 rounded active:scale-95 transition-all"
                    >
                      {verifyingEmail === acc.email ? 'Switching...' : 'Switch'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  }
}
