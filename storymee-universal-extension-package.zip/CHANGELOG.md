---
type: docs
title: CHANGELOG
description: OKF standardized document for CHANGELOG in project universal-ai-extension.
tags: [universal-ai-extension]
related_files: [file:///C:/storymee/5-Extension-Automations/universal-ai-extension/CHANGELOG.md]
---

# Changelog - Universal AI Director Extension

All notable changes to the Universal AI Director Extension will be documented in this file.

## [1.1.0] - 2026-06-25

### Added
- **Manual Gateway URL Save**: Added a dedicated "Lưu" (Save) button next to the Gateway connection URL input in both Sidepanel and Dashboard Full-Screen settings to support manual Cloudflare Tunnel URLs saving and triggering hot WS reconnects.

### Fixed
- **WebSocket Status Infinite Loop**: Excluded `"workerState"` from the storage change listener's `apiKeys` array in `src/background.ts`, resolving the infinite reconnect loop causing status toggling madness.

### Changed
- **Sidepanel Redesign**: Streamlined the Extension's Sidepanel UI down to two focused tabs:
  - **Giám sát (Monitor)**: Displays connection status, Route Badge (Local/VPS), a compact 2x2 stats matrix, a list of active processing/pending jobs, and 3 recently completed/failed jobs.
  - **Cài đặt (Settings)**: Houses Google identity status, Worker name config, Gateway URL config (with Local/VPS presets and manual Save), Hub decryption key sync, active providers status, and the quick account switcher.
- **Route Options Streamlining**: Removed the "Production" preset option from the gateway config in both Sidepanel and Dashboard Full-Screen layouts. Reduced grid layouts to `grid-cols-2` to align with the simplified Local and VPS preset scheme.

## [1.0.0] - 2026-05-30

### Added
- **Premium Control Deck Dashboard**: Developed a high-end React 19 visual control dashboard in `src/App.tsx` incorporating a vibrant modern HSL dark theme, glassmorphic status panels, real-time WebSocket connection state, an interactive Manual Task Console bypassing Google reCAPTCHA, active driver configuration cards (Google Labs, Picsart, Dreamina, TopView), and an inline media history sync player.
- **Chrome Extension Entrypoints**: Hooked up Vite production bundle mapping for both sidepanel (`sidepanel.html` -> `src/sidepanel/main.tsx`) and options dashboard (`index.html` -> `src/dashboard/main.tsx`).
- **Global Vite Types**: Introduced `src/vite-env.d.ts` supporting standard CSS module references (`../index.css`).

### Fixed
- **WebCrypto Sign Typing Mismatch**: Patched `src/utils/crypto.ts` casting parameter payloads to prevent strict engine compiler type collisions between typed array representations.
- **Unused Local Imports & Variables**: Refactored `src/background.ts` and `src/App.tsx` to scrub unused dependencies, keeping `noUnusedLocals` compiler standard happy.
- **Chrome Storage Type Casting**: Cast `chrome.storage.local.get` callback values to `any` globally inside background threads and UI dashboards to resolve typing mismatches with strict empty object defaults.
